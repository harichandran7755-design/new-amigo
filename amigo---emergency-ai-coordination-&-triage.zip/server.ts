import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.resolve(__dirname, 'data', 'database.json');

// Ensure database directory and file exist
function getDb() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const initialDb = {
        hospitals: [],
        ambulances: [],
        reservations: [],
        cases: [],
      };
      fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
      fs.writeFileSync(DB_FILE, JSON.stringify(initialDb, null, 2), 'utf-8');
      return initialDb;
    }
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading database file:', err);
    return { hospitals: [], ambulances: [], reservations: [], cases: [] };
  }
}

function saveDb(db: any) {
  try {
    fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving database file:', err);
  }
}

// Initialize Gemini Client
const geminiApiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: geminiApiKey || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json());

  // -------------------------------------------------------------
  // CASES API
  // -------------------------------------------------------------
  app.get('/api/cases', (req: Request, res: Response) => {
    const db = getDb();
    const cases = (db.cases || []).sort(
      (a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    res.json(cases);
  });

  app.get('/api/cases/:id', (req: Request, res: Response) => {
    const db = getDb();
    const found = (db.cases || []).find((c: any) => c.id === req.params.id);
    if (!found) {
      return res.status(404).json({ error: 'Case not found' });
    }
    res.json(found);
  });

  app.post('/api/cases', (req: Request, res: Response) => {
    const db = getDb();
    const newCase = {
      id: `CASE-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString(),
      ...req.body,
    };
    db.cases = db.cases || [];
    db.cases.unshift(newCase);
    saveDb(db);
    res.status(201).json(newCase);
  });

  app.patch('/api/cases/:id', (req: Request, res: Response) => {
    const db = getDb();
    db.cases = db.cases || [];
    const index = db.cases.findIndex((c: any) => c.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Case not found' });
    }
    db.cases[index] = { ...db.cases[index], ...req.body };
    saveDb(db);
    res.json(db.cases[index]);
  });

  // -------------------------------------------------------------
  // HOSPITALS API
  // -------------------------------------------------------------
  app.get('/api/hospitals', (req: Request, res: Response) => {
    const db = getDb();
    res.json(db.hospitals || []);
  });

  app.patch('/api/hospitals/:id', (req: Request, res: Response) => {
    const db = getDb();
    db.hospitals = db.hospitals || [];
    const index = db.hospitals.findIndex((h: any) => h.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Hospital not found' });
    }
    db.hospitals[index] = { ...db.hospitals[index], ...req.body };
    saveDb(db);
    res.json(db.hospitals[index]);
  });

  // -------------------------------------------------------------
  // AMBULANCES API
  // -------------------------------------------------------------
  app.get('/api/ambulances', (req: Request, res: Response) => {
    const db = getDb();
    res.json(db.ambulances || []);
  });

  app.patch('/api/ambulances/:id', (req: Request, res: Response) => {
    const db = getDb();
    db.ambulances = db.ambulances || [];
    const index = db.ambulances.findIndex((a: any) => a.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Ambulance not found' });
    }
    db.ambulances[index] = { ...db.ambulances[index], ...req.body };
    saveDb(db);
    res.json(db.ambulances[index]);
  });

  // -------------------------------------------------------------
  // RESERVATIONS API
  // -------------------------------------------------------------
  app.get('/api/reservations', (req: Request, res: Response) => {
    const db = getDb();
    const reservations = (db.reservations || []).sort(
      (a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    res.json(reservations);
  });

  app.post('/api/reservations', (req: Request, res: Response) => {
    const db = getDb();
    const newReservation = {
      id: `RES-${Math.floor(1000 + Math.random() * 9000)}`,
      createdAt: new Date().toISOString(),
      status: 'RESERVED',
      ...req.body,
    };
    db.reservations = db.reservations || [];
    db.reservations.unshift(newReservation);

    // If assigned to an ambulance, update ambulance status
    if (req.body.ambulanceId) {
      const ambIndex = (db.ambulances || []).findIndex((a: any) => a.id === req.body.ambulanceId);
      if (ambIndex !== -1) {
        db.ambulances[ambIndex].destination = req.body.hospitalName;
        db.ambulances[ambIndex].patientName = req.body.patientName;
        db.ambulances[ambIndex].status = 'EN ROUTE';
      }
    }

    saveDb(db);
    res.status(201).json(newReservation);
  });

  app.patch('/api/reservations/:id', (req: Request, res: Response) => {
    const db = getDb();
    db.reservations = db.reservations || [];
    const index = db.reservations.findIndex((r: any) => r.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Reservation not found' });
    }
    db.reservations[index] = { ...db.reservations[index], ...req.body };
    saveDb(db);
    res.json(db.reservations[index]);
  });

  app.delete('/api/reservations/:id', (req: Request, res: Response) => {
    const db = getDb();
    db.reservations = db.reservations || [];
    const beforeLen = db.reservations.length;
    db.reservations = db.reservations.filter((r: any) => r.id !== req.params.id);
    if (db.reservations.length === beforeLen) {
      return res.status(404).json({ error: 'Reservation not found' });
    }
    saveDb(db);
    res.json({ success: true, message: 'Reservation cancelled' });
  });

  // -------------------------------------------------------------
  // GEMINI AI INSIGHTS API
  // -------------------------------------------------------------
  app.post('/api/ai/analyze-patient', async (req: Request, res: Response) => {
    try {
      const { patient, vitals } = req.body;

      if (!patient || !vitals) {
        return res.status(400).json({ error: 'Missing patient or vitals data' });
      }

      // Compute deterministic baseline triage score
      let ruleScore = 0;
      const hr = Number(vitals.heartRate) || 80;
      const bp = Number(vitals.bp) || 120;
      const spo2 = Number(vitals.spo2) || 98;
      const resp = Number(vitals.respRate) || 16;
      const temp = Number(vitals.temperature) || 37;
      const pain = Number(vitals.painLevel) || 0;
      const glucose = Number(vitals.glucose) || 100;
      const conscious = vitals.consciousness;
      const trauma = vitals.trauma;

      if (hr >= 120 || hr < 50) ruleScore += 20;
      if (bp < 90) ruleScore += 25;
      if (spo2 < 90) ruleScore += 30;
      else if (spo2 < 94) ruleScore += 15;
      if (resp >= 25 || resp < 10) ruleScore += 15;
      if (temp >= 39 || temp < 35) ruleScore += 10;
      if (conscious === 'Confused') ruleScore += 15;
      if (conscious === 'Unconscious') ruleScore += 30;
      if (trauma === 'Yes') ruleScore += 15;
      if (pain >= 8) ruleScore += 10;
      if (glucose < 60 || glucose > 300) ruleScore += 15;

      ruleScore = Math.min(ruleScore, 100);

      const baselineNeeds = {
        ICU: ruleScore >= 70 || conscious === 'Unconscious',
        Oxygen: ruleScore >= 70 || spo2 < 94,
        Specialist: ruleScore >= 70 || trauma === 'Yes' || conscious === 'Unconscious',
        Trauma: trauma === 'Yes',
        Ventilator: spo2 < 85 || conscious === 'Unconscious',
        CT: trauma === 'Yes' || conscious !== 'Alert',
        Cardiac: hr >= 120 || hr < 50 || patient.emergencyType?.includes('Cardiac'),
        Surgery: trauma === 'Yes' && ruleScore >= 60,
      };

      // Prompt Gemini for deep clinical reasoning and emergency action directives
      const prompt = `You are AMIGO AI, an expert Emergency Medicine Physician and Trauma Dispatch Director.
Analyze this emergency patient and vital signs to provide triage severity, critical clinical insights, in-transit paramedic stabilization directives, hospital resource matching, and SBAR hospital handover briefing.

Patient Information:
- Name: ${patient.name || 'Unknown'}
- Age: ${patient.age || 'Unknown'}
- Gender: ${patient.gender || 'Unknown'}
- Blood Group: ${patient.bloodGroup || 'Unknown'}
- Emergency Type: ${patient.emergencyType || 'General Emergency'}
- Ambulance Unit: ${patient.ambulanceId || 'AMB-204'}

Vital Signs & Clinical Signs:
- Blood Pressure (Systolic): ${bp} mmHg
- Heart Rate: ${hr} BPM
- SpO2: ${spo2}%
- Respiratory Rate: ${resp} breaths/min
- Body Temperature: ${temp}°C
- Consciousness Level: ${conscious}
- Trauma Present: ${trauma}
- Pain Level: ${pain}/10
- Blood Glucose: ${glucose} mg/dL

Baseline Rule Score: ${ruleScore}/100.
Evaluate whether this is CRITICAL, URGENT, or STABLE.
Return precise medical directives and emergency protocols.`;

      let aiResult: any = null;

      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            systemInstruction:
              'You are AMIGO AI, a real-time Emergency Medical and Trauma Dispatch Intelligence System. Provide clinically sound, rapid emergency medicine assessments in JSON format.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                severityScore: {
                  type: Type.INTEGER,
                  description: 'Emergency Severity Score from 0 to 100',
                },
                severityTier: {
                  type: Type.STRING,
                  description: 'CRITICAL, URGENT, or STABLE',
                },
                clinicalImpression: {
                  type: Type.STRING,
                  description: 'Concise medical impression synthesizing vitals and clinical risks',
                },
                criticalRisks: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: 'List of top 2 to 4 immediate life-threatening risks',
                },
                requiredResources: {
                  type: Type.OBJECT,
                  properties: {
                    ICU: { type: Type.BOOLEAN },
                    Oxygen: { type: Type.BOOLEAN },
                    Specialist: { type: Type.BOOLEAN },
                    Trauma: { type: Type.BOOLEAN },
                    Ventilator: { type: Type.BOOLEAN },
                    CT: { type: Type.BOOLEAN },
                    Cardiac: { type: Type.BOOLEAN },
                    Surgery: { type: Type.BOOLEAN },
                  },
                  required: ['ICU', 'Oxygen', 'Specialist', 'Trauma', 'Ventilator', 'CT', 'Cardiac', 'Surgery'],
                },
                inTransitDirectives: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: '3 to 5 step-by-step EMT paramedic action directives to stabilize patient en route',
                },
                recommendedHospitalRationale: {
                  type: Type.STRING,
                  description: 'Clinical justification for selected emergency department resources and readiness',
                },
                hospitalHandoverProtocol: {
                  type: Type.STRING,
                  description: 'Structured SBAR (Situation-Background-Assessment-Recommendation) handover message for the receiving hospital',
                },
                alertLevel: {
                  type: Type.STRING,
                  description: 'Hospital code or alert tier (e.g. Code STEMI, Trauma Team Delta, Code Stroke, Level 1 Rapid Triage, Standard Emergency)',
                },
              },
              required: [
                'severityScore',
                'severityTier',
                'clinicalImpression',
                'criticalRisks',
                'requiredResources',
                'inTransitDirectives',
                'recommendedHospitalRationale',
                'hospitalHandoverProtocol',
                'alertLevel',
              ],
            },
          },
        });

        const rawText = response.text?.trim() || '';
        aiResult = JSON.parse(rawText);
      } catch (geminiError: any) {
        console.warn('Gemini API call failed or unavailable, falling back to algorithmic triage:', geminiError?.message);

        const severity = ruleScore >= 70 ? 'CRITICAL' : ruleScore >= 35 ? 'URGENT' : 'STABLE';
        aiResult = {
          severityScore: ruleScore,
          severityTier: severity,
          clinicalImpression: `${patient.emergencyType || 'Emergency'} presentation with vitals HR ${hr} BPM, BP ${bp} mmHg, SpO2 ${spo2}%, consciousness ${conscious}. Requires prompt hospital resource pre-alert and continuous monitoring.`,
          criticalRisks: [
            bp < 90 ? 'Hypotension and cardiovascular decompensation' : 'Hemodynamic instability',
            spo2 < 92 ? 'Severe hypoxemia and respiratory distress' : 'Airway compromise risk',
            conscious !== 'Alert' ? 'Decreased neurological responsiveness' : 'Pain and stress-induced cardiac workload',
          ],
          requiredResources: baselineNeeds,
          inTransitDirectives: [
            spo2 < 94 ? 'Apply high-flow O2 via non-rebreather mask (10-15 L/min)' : 'Maintain nasal cannula O2 if SpO2 drops',
            'Establish 18G peripheral IV line and monitor cardiac telemetry continuously',
            'Recheck vitals every 3 minutes and record in ambulance log',
            'Pre-alert receiving hospital emergency department via radio channel',
          ],
          recommendedHospitalRationale:
            'Facility matches required critical care amenities (ICU, Imaging, Specialty Team) within minimum transit window.',
          hospitalHandoverProtocol: `SBAR: Patient ${patient.name || 'Unknown'}, ${patient.age || 'Age N/A'}, presenting with ${patient.emergencyType}. BP ${bp}/${Math.round(bp * 0.65)}, HR ${hr}, SpO2 ${spo2}%. Paramedics en route with estimated arrival in 7-10 minutes.`,
          alertLevel: severity === 'CRITICAL' ? 'Code RED - Immediate Trauma/Resuscitation' : 'Level 2 Urgent Triage Pre-Alert',
        };
      }

      // Merge with ruleScore to ensure medical safety floor
      const finalScore = Math.max(ruleScore, Number(aiResult.severityScore) || ruleScore);
      const finalSeverity = finalScore >= 70 ? 'CRITICAL' : finalScore >= 35 ? 'URGENT' : 'STABLE';

      // Ensure required resources reflect critical clinical criteria
      const mergedResources = {
        ...baselineNeeds,
        ...(aiResult.requiredResources || {}),
        ICU: baselineNeeds.ICU || !!aiResult.requiredResources?.ICU,
        Oxygen: baselineNeeds.Oxygen || !!aiResult.requiredResources?.Oxygen,
        Ventilator: baselineNeeds.Ventilator || !!aiResult.requiredResources?.Ventilator,
        Specialist: baselineNeeds.Specialist || !!aiResult.requiredResources?.Specialist,
        Trauma: baselineNeeds.Trauma || !!aiResult.requiredResources?.Trauma,
      };

      res.json({
        ...aiResult,
        severityScore: finalScore,
        severityTier: finalSeverity,
        requiredResources: mergedResources,
      });
    } catch (error: any) {
      console.error('Error during patient analysis:', error);
      res.status(500).json({ error: error.message || 'Failed to analyze patient' });
    }
  });

  // Paramedic Copilot / Clinical Question Answering
  app.post('/api/ai/ask-assistant', async (req: Request, res: Response) => {
    try {
      const { question, patientContext } = req.body;
      if (!question) {
        return res.status(400).json({ error: 'Question is required' });
      }

      const prompt = `You are AMIGO Emergency Medical AI Copilot, advising an in-transit paramedic and emergency coordination team.
Answer the clinical query concisely with actionable, step-by-step emergency medical protocols.

Patient Context:
${patientContext ? JSON.stringify(patientContext, null, 2) : 'No specific patient assigned.'}

Paramedic / Coordinator Query:
${question}

Provide response with:
1. Immediate action (first 30 seconds)
2. Medication / Intervention instructions (doses, contraindications)
3. Caution / Red flags to monitor`;

      let answer = '';
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            systemInstruction:
              'You are a high-speed Emergency Medical Services (EMS) Medical Director. Give clear, bulleted, authoritative paramedic protocols.',
          },
        });
        answer = response.text || 'Protocol recommendation received.';
      } catch (geminiError: any) {
        answer = `Standard Emergency Protocol:
1. Immediate Action: Check ABCs (Airway, Breathing, Circulation), apply 15L O2 via non-rebreather mask, secure second IV line.
2. Interventions: Administer normal saline bolus (250-500mL) if hypotensive; record 12-lead ECG immediately.
3. Precautions: Re-assess vitals every 2 minutes. Transmit real-time telemetry to receiving hospital.`;
      }

      res.json({ answer });
    } catch (err: any) {
      console.error('Error in ask-assistant:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // Radio Patch Audio/Text Generation
  app.post('/api/ai/hospital-briefing', async (req: Request, res: Response) => {
    try {
      const { patient, vitals, triage, hospitalName } = req.body;

      const prompt = `Compose a professional 30-second standard Emergency Medical Services (EMS) radio patch broadcast from Ambulance ${patient?.ambulanceId || 'AMB-204'} calling ${hospitalName || 'Receiving Hospital Emergency Department'}.
Include: Unit ID, patient age/gender, chief complaint, ETA, vitals, interventions performed, and requested preparation (e.g. trauma bay, cath lab, intubation team).
Keep it authentic, disciplined, and standardized for emergency telemetry.`;

      let transcript = '';
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
        });
        transcript = response.text || 'EMS radio patch transmission established.';
      } catch (err) {
        transcript = `Ambulance ${patient?.ambulanceId || 'AMB-204'} to ${hospitalName || 'CityCare Emergency'}, incoming priority traffic. We have a ${patient?.age || '55'}-year-old ${patient?.gender || 'patient'} with ${patient?.emergencyType || 'acute medical emergency'}. Current vitals: BP ${vitals?.bp || '80'}, Pulse ${vitals?.heartRate || '120'}, SpO2 ${vitals?.spo2 || '89'}%. High flow oxygen started, 18G IV secured. ETA is 7 minutes. Please have your resuscitation bay and critical care team on standby. Over.`;
      }

      res.json({ transcript });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // -------------------------------------------------------------
  // VITE OR STATIC FRONTEND SERVING
  // -------------------------------------------------------------
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AMIGO Emergency Backend & Dev Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start AMIGO server:', err);
  process.exit(1);
});
