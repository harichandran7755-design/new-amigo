/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { Topbar } from './components/Topbar';
import { CallModal } from './components/CallModal';
import { CopilotModal } from './components/CopilotModal';
import { DashboardView } from './views/DashboardView';
import { AnalysisView } from './views/AnalysisView';
import { LiveMapView } from './views/LiveMapView';
import { AmbulancesView } from './views/AmbulancesView';
import { HospitalNetworkView } from './views/HospitalNetworkView';
import { ResourceStatusView } from './views/ResourceStatusView';
import { ReservationsView } from './views/ReservationsView';
import { CaseHistoryView } from './views/CaseHistoryView';
import { api } from './services/api';
import {
  PatientInfo,
  MedicalVitals,
  AIAnalysisResult,
  Hospital,
  Ambulance,
  Reservation,
  EmergencyCase,
  ResourceRequirements,
} from './types';

export default function App() {
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [online, setOnline] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Backend Data Collections
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [ambulances, setAmbulances] = useState<Ambulance[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [cases, setCases] = useState<EmergencyCase[]>([]);

  // Active Patient & Telemetry State
  const [patient, setPatient] = useState<PatientInfo>({
    name: 'A. Ramesh',
    age: 58,
    gender: 'Male',
    bloodGroup: 'O+',
    emergencyType: 'Cardiac Emergency',
    ambulanceId: 'AMB-204',
  });

  const [vitals, setVitals] = useState<MedicalVitals>({
    bp: 80,
    heartRate: 125,
    spo2: 89,
    temperature: 37,
    respRate: 25,
    consciousness: 'Confused',
    trauma: 'No',
    painLevel: 9,
    glucose: 100,
  });

  const [aiResult, setAiResult] = useState<AIAnalysisResult | null>(null);
  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [savingCase, setSavingCase] = useState<boolean>(false);

  // Recommended & Backup Hospital Selection
  const [recommendedHospital, setRecommendedHospital] = useState<Hospital | null>(null);
  const [backupHospital, setBackupHospital] = useState<Hospital | null>(null);

  // Modal States
  const [callModalOpen, setCallModalOpen] = useState<boolean>(false);
  const [selectedCallHospital, setSelectedCallHospital] = useState<Hospital | null>(null);
  const [copilotModalOpen, setCopilotModalOpen] = useState<boolean>(false);

  // Fetch all backend data
  const fetchData = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const [hospData, ambData, resData, caseData] = await Promise.all([
        api.getHospitals().catch(() => []),
        api.getAmbulances().catch(() => []),
        api.getReservations().catch(() => []),
        api.getCases().catch(() => []),
      ]);

      setHospitals(hospData);
      setAmbulances(ambData);
      setReservations(resData);
      setCases(caseData);
      setOnline(true);

      // Default hospitals if not yet selected
      if (!recommendedHospital && hospData.length > 0) {
        setRecommendedHospital(hospData[0]);
        setBackupHospital(hospData[1] || hospData[0]);
      }
    } catch (err) {
      console.error('Data sync error:', err);
      setOnline(false);
    } finally {
      setIsRefreshing(false);
    }
  }, [recommendedHospital]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Matching algorithm: Filters hospitals by required resources and sorts by ETA
  const matchHospital = useCallback(
    (needs: ResourceRequirements, hospitalList: Hospital[]) => {
      const eligible = hospitalList.filter((h) => {
        if (needs.ICU && !h.icu) return false;
        if (needs.Oxygen && !h.oxygen) return false;
        if (needs.Specialist && !h.specialist) return false;
        if (needs.Trauma && !h.trauma) return false;
        if (needs.Ventilator && !h.ventilator) return false;
        if (needs.CT && !h.ct) return false;
        if (needs.Cardiac && !h.cardiac) return false;
        if (needs.Surgery && !h.surgery) return false;
        return true;
      });

      const sorted = (eligible.length > 0 ? eligible : hospitalList).slice().sort(
        (a, b) => a.eta - b.eta
      );

      const best = sorted[0] || hospitalList[0];
      const backup = sorted.find((h) => h.id !== best.id) || hospitalList.find((h) => h.id !== best.id) || best;

      return { best, backup };
    },
    []
  );

  // Trigger Gemini AI Patient Analysis & Hospital Matching
  const handleAnalyzePatient = async () => {
    setAnalyzing(true);
    try {
      const result = await api.analyzePatient(patient, vitals);
      setAiResult(result);

      if (hospitals.length > 0) {
        const { best, backup } = matchHospital(result.requiredResources, hospitals);
        setRecommendedHospital(best);
        setBackupHospital(backup);
      }
    } catch (err: any) {
      console.error('Analysis failed:', err);
      alert(`AI Analysis error: ${err.message || 'Please check backend logs.'}`);
    } finally {
      setAnalyzing(false);
    }
  };

  // Save Case to Backend Database
  const handleSaveCase = async () => {
    if (!aiResult) return;
    setSavingCase(true);
    try {
      const newCase = await api.saveCase({
        patient,
        vitals,
        triage: {
          score: aiResult.severityScore,
          severity: aiResult.severityTier,
          needs: aiResult.requiredResources,
        },
        aiInsights: aiResult,
        assignedHospitalId: recommendedHospital?.id || 'hosp-1',
        assignedHospitalName: recommendedHospital?.name || 'CityCare Emergency Hospital',
        backupHospitalId: backupHospital?.id || 'hosp-2',
        backupHospitalName: backupHospital?.name || 'Metro Medical Center',
        status: 'EN_ROUTE',
      });

      setCases((prev) => [newCase, ...prev]);
      alert(`Case ${newCase.id} successfully stored in backend database!`);
    } catch (err) {
      console.error('Failed to save case:', err);
      alert('Error saving case to database.');
    } finally {
      setSavingCase(false);
    }
  };

  // Load a stored case into active dispatch
  const handleLoadCase = (caseItem: EmergencyCase) => {
    setPatient(caseItem.patient);
    setVitals(caseItem.vitals);
    if (caseItem.aiInsights) {
      setAiResult(caseItem.aiInsights);
    }
    const foundHosp = hospitals.find((h) => h.id === caseItem.assignedHospitalId);
    if (foundHosp) setRecommendedHospital(foundHosp);
    setActiveView('dashboard');
  };

  // Trigger Hospital Call Modal
  const handleCallHospital = (hospital: Hospital) => {
    setSelectedCallHospital(hospital);
    setCallModalOpen(true);
  };

  // Dynamic View Titles
  const viewTitles: Record<string, { title: string; subtitle: string }> = {
    dashboard: {
      title: 'Emergency Coordination Dashboard',
      subtitle: 'AI-assisted ambulance → hospital coordination & real-time telemetry',
    },
    analysis: {
      title: 'AI Clinical Patient Analysis',
      subtitle: 'Gemini 3.8 Flash triage reasoning, SBAR hospital handover, and stabilization directives',
    },
    mapView: {
      title: 'Live Tactical GPS Map',
      subtitle: 'Real-time telemetry, routing radar, and fleet coordinates',
    },
    ambulances: {
      title: 'Active Ambulance Fleet',
      subtitle: 'Unit telemetry, status tracking, paramedic crew allocations, and destination hubs',
    },
    hospitals: {
      title: 'Hospital Emergency Network',
      subtitle: 'Trauma capability matrix, resource availability toggles, and live occupancy',
    },
    resources: {
      title: 'Hospital Resource Status',
      subtitle: 'Surge occupancy meters, ICU bed counts, and critical care infrastructure',
    },
    reservations: {
      title: 'Active Resource Locks & Reservations',
      subtitle: 'Pre-allocating ICU beds, ventilators, and surgical bays ahead of ambulance arrival',
    },
    caseHistory: {
      title: 'Stored Case History & Database Logs',
      subtitle: 'Persistent database records, vital sign telemetry, and past emergency dispatches',
    },
    copilot: {
      title: 'Paramedic Emergency Copilot',
      subtitle: 'Instant clinical directives, emergency drug dosing, and resuscitation protocols',
    },
  };

  const currentHeader = viewTitles[activeView] || viewTitles.dashboard;
  const currentHospital = recommendedHospital || hospitals[0] || ({} as Hospital);
  const currentBackup = backupHospital || hospitals[1] || hospitals[0] || ({} as Hospital);

  return (
    <div className="flex min-h-screen bg-[#080d0b] text-[#e7ece9] font-sans">
      {/* SIDEBAR */}
      <Sidebar
        activeView={activeView}
        onSelectView={setActiveView}
        online={online}
        activeCaseCount={cases.length}
      />

      {/* MAIN CONTENT AREA */}
      <main className="ml-64 w-[calc(100%-16rem)] flex flex-col min-h-screen">
        <Topbar
          title={currentHeader.title}
          subtitle={currentHeader.subtitle}
          activeAmbulanceUnit={patient.ambulanceId}
          assignedHospital={currentHospital.name}
          onOpenCopilot={() => setCopilotModalOpen(true)}
          onRefreshData={fetchData}
          isRefreshing={isRefreshing}
        />

        <div className="p-7 flex-1">
          {activeView === 'dashboard' && (
            <DashboardView
              patient={patient}
              setPatient={setPatient}
              vitals={vitals}
              setVitals={setVitals}
              aiResult={aiResult}
              analyzing={analyzing}
              onAnalyze={handleAnalyzePatient}
              recommendedHospital={currentHospital}
              backupHospital={currentBackup}
              hospitals={hospitals}
              onCallHospital={handleCallHospital}
              onSaveCase={handleSaveCase}
              savingCase={savingCase}
              onOpenAnalysisTab={() => setActiveView('analysis')}
              onSelectHospital={(h) => setRecommendedHospital(h)}
            />
          )}

          {activeView === 'analysis' && (
            <AnalysisView
              patient={patient}
              vitals={vitals}
              aiResult={aiResult}
              recommendedHospital={currentHospital}
              onAnalyze={handleAnalyzePatient}
              analyzing={analyzing}
            />
          )}

          {activeView === 'mapView' && (
            <LiveMapView
              recommendedHospital={currentHospital}
              ambulances={ambulances}
              hospitals={hospitals}
            />
          )}

          {activeView === 'ambulances' && (
            <AmbulancesView
              ambulances={ambulances}
              hospitals={hospitals}
              onRefresh={fetchData}
            />
          )}

          {activeView === 'hospitals' && (
            <HospitalNetworkView
              hospitals={hospitals}
              onRefresh={fetchData}
              onCallHospital={handleCallHospital}
            />
          )}

          {activeView === 'resources' && (
            <ResourceStatusView hospitals={hospitals} />
          )}

          {activeView === 'reservations' && (
            <ReservationsView
              reservations={reservations}
              hospitals={hospitals}
              onRefresh={fetchData}
            />
          )}

          {activeView === 'caseHistory' && (
            <CaseHistoryView
              cases={cases}
              onLoadCase={handleLoadCase}
              onRefresh={fetchData}
            />
          )}

          {activeView === 'copilot' && (
            <div className="max-w-3xl mx-auto py-6">
              <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-6 shadow-xl text-center">
                <h2 className="text-xl font-bold text-[#e1e9e4] mb-2">
                  Emergency Paramedic Copilot
                </h2>
                <p className="text-xs text-[#718077] mb-6 max-w-md mx-auto">
                  Click below to open the real-time AI copilot console for emergency resuscitation directives and drug dosages during patient transport.
                </p>
                <button
                  onClick={() => setCopilotModalOpen(true)}
                  className="px-6 py-3 rounded-xl bg-[#237344] hover:bg-[#2b8250] text-[#f1fff6] font-bold text-xs border border-[#3f9a63] shadow-[0_0_15px_rgba(50,145,87,0.3)] transition-all cursor-pointer"
                >
                  OPEN COPILOT CONSOLE
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* HOSPITAL COORDINATION & RADIO TELEMETRY MODAL */}
      {selectedCallHospital && (
        <CallModal
          isOpen={callModalOpen}
          onClose={() => setCallModalOpen(false)}
          hospital={selectedCallHospital}
          patient={patient}
          vitals={vitals}
          aiResult={aiResult}
          onReservationCreated={fetchData}
        />
      )}

      {/* PARAMEDIC COPILOT MODAL */}
      <CopilotModal
        isOpen={copilotModalOpen}
        onClose={() => setCopilotModalOpen(false)}
        patient={patient}
        vitals={vitals}
        aiResult={aiResult}
      />
    </div>
  );
}
