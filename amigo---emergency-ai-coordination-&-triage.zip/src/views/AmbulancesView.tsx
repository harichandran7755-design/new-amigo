import React from 'react';
import { Ambulance, Hospital } from '../types';
import { Ambulance as AmbIcon, UserCheck, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { api } from '../services/api';

interface AmbulancesViewProps {
  ambulances: Ambulance[];
  hospitals: Hospital[];
  onRefresh: () => void;
}

export const AmbulancesView: React.FC<AmbulancesViewProps> = ({
  ambulances,
  hospitals,
  onRefresh,
}) => {
  const handleStatusChange = async (ambId: string, newStatus: Ambulance['status']) => {
    try {
      await api.updateAmbulance(ambId, { status: newStatus });
      onRefresh();
    } catch (err) {
      console.error('Failed to update ambulance status:', err);
    }
  };

  const handleDestinationChange = async (ambId: string, destination: string) => {
    try {
      await api.updateAmbulance(ambId, { destination });
      onRefresh();
    } catch (err) {
      console.error('Failed to update destination:', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#14261c] border border-[#327048] flex items-center justify-center text-[#54c984]">
            <AmbIcon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#e1e9e4]">
              Active Ambulance Fleet Telemetry
            </h2>
            <p className="text-xs text-[#718077]">
              Real-time monitoring, crew assignments, and destination routing
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono px-3 py-1 rounded-lg bg-[#111c16] border border-[#233a2c] text-[#54c984]">
            Active Units: {ambulances.length}
          </span>
        </div>
      </div>

      {/* AMBULANCES TABLE & CARDS */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1d2721] text-[#737f78]">
                <th className="py-3 px-3">Unit ID</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Paramedic & Driver</th>
                <th className="py-3 px-3">Active Patient</th>
                <th className="py-3 px-3">Destination Hospital</th>
                <th className="py-3 px-3">Location & Speed</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {ambulances.map((amb) => (
                <tr
                  key={amb.id}
                  className="border-b border-[#1d2721] text-[#d2dcd7] hover:bg-[#121915]"
                >
                  <td className="py-3.5 px-3 font-mono font-bold text-[#e1e9e4]">
                    {amb.id}
                  </td>
                  <td className="py-3.5 px-3">
                    <span
                      className={`inline-block px-2.5 py-1 rounded-md text-[10px] font-mono font-bold border ${
                        amb.status === 'EN ROUTE'
                          ? 'bg-[#291818] border-[#5a2e2e] text-rose-300 animate-pulse'
                          : amb.status === 'AVAILABLE'
                          ? 'bg-[#132419] border-[#2c5339] text-[#54c984]'
                          : amb.status === 'ON SCENE'
                          ? 'bg-[#282110] border-[#55431d] text-amber-300'
                          : 'bg-[#151e26] border-[#293d4f] text-cyan-300'
                      }`}
                    >
                      {amb.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-3">
                    <div className="font-semibold text-[#dfe6e2]">{amb.paramedic}</div>
                    <div className="text-[10px] text-[#6d7c73]">Driver: {amb.driverName}</div>
                  </td>
                  <td className="py-3.5 px-3 font-medium">
                    {amb.patientName ? (
                      <span className="text-[#54c984] font-semibold">{amb.patientName}</span>
                    ) : (
                      <span className="text-[#64756b]">No Patient</span>
                    )}
                  </td>
                  <td className="py-3.5 px-3">
                    <select
                      value={amb.destination || ''}
                      onChange={(e) => handleDestinationChange(amb.id, e.target.value)}
                      className="bg-[#090f0c] text-xs text-[#dfe6e2] border border-[#253029] rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#4b8d65]"
                    >
                      <option value="">-- No Destination --</option>
                      {hospitals.map((h) => (
                        <option key={h.id} value={h.name}>
                          {h.name} ({h.eta} min)
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="py-3.5 px-3 font-mono text-[11px] text-[#86998e]">
                    <div>{amb.location}</div>
                    <div className="text-[10px] text-[#54c984]">{amb.speed}</div>
                  </td>
                  <td className="py-3.5 px-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleStatusChange(amb.id, 'EN ROUTE')}
                        title="Set En Route"
                        className="px-2 py-1 rounded bg-[#1e1515] hover:bg-[#2e1d1d] text-rose-300 border border-[#482828] text-[10px] font-mono"
                      >
                        En Route
                      </button>
                      <button
                        onClick={() => handleStatusChange(amb.id, 'AVAILABLE')}
                        title="Set Available"
                        className="px-2 py-1 rounded bg-[#132218] hover:bg-[#1b3424] text-[#54c984] border border-[#274f35] text-[10px] font-mono"
                      >
                        Available
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
