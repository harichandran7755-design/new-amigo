import React, { useState } from 'react';
import { EmergencyCase } from '../types';
import { History, FileText, ArrowRight, Calendar, User, Activity, CheckCircle } from 'lucide-react';

interface CaseHistoryViewProps {
  cases: EmergencyCase[];
  onLoadCase: (caseItem: EmergencyCase) => void;
  onRefresh: () => void;
}

export const CaseHistoryView: React.FC<CaseHistoryViewProps> = ({
  cases,
  onLoadCase,
}) => {
  const [selectedCase, setSelectedCase] = useState<EmergencyCase | null>(cases[0] || null);

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#14261c] border border-[#327048] flex items-center justify-center text-[#54c984]">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#e1e8e4]">
              Stored Emergency Cases & Dispatch Logs Database
            </h2>
            <p className="text-xs text-[#718077]">
              Persistent emergency records, vital signs telemetry, and AI clinical assessments
            </p>
          </div>
        </div>

        <span className="text-xs font-mono px-3 py-1 rounded-lg bg-[#111c16] border border-[#233a2c] text-[#54c984]">
          Stored Records: {cases.length}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* CASES LIST */}
        <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-4 shadow-lg space-y-2.5 max-h-[700px] overflow-y-auto">
          <div className="text-xs font-bold text-[#6f8076] uppercase tracking-wider px-2 py-1">
            Dispatch Case Index
          </div>

          {cases.length === 0 ? (
            <div className="text-center py-10 text-xs text-[#6e7d74]">
              No emergency cases stored in database yet.
            </div>
          ) : (
            cases.map((c) => {
              const isSelected = selectedCase?.id === c.id;
              const dateStr = new Date(c.createdAt).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={c.id}
                  onClick={() => setSelectedCase(c)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#15241c] border-[#347851] shadow-[0_0_12px_rgba(52,120,81,0.15)]'
                      : 'bg-[#090f0c] border-[#202a23] hover:border-[#2d3d32]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-mono text-xs font-bold text-[#e1e9e4]">
                      {c.id}
                    </span>
                    <span
                      className={`text-[9px] font-mono px-2 py-0.5 rounded font-bold ${
                        c.triage.severity === 'CRITICAL'
                          ? 'bg-[#2b1717] text-rose-300 border border-[#592c2c]'
                          : c.triage.severity === 'URGENT'
                          ? 'bg-[#292212] text-amber-300 border border-[#52411e]'
                          : 'bg-[#132318] text-[#54c984] border border-[#2b5437]'
                      }`}
                    >
                      {c.triage.severity} ({c.triage.score}/100)
                    </span>
                  </div>

                  <div className="font-semibold text-xs text-[#dbe5df] truncate">
                    {c.patient.name || 'Unknown Patient'} ({c.patient.age}y, {c.patient.gender})
                  </div>

                  <div className="text-[11px] text-[#7d8f85] mt-1 flex items-center justify-between">
                    <span>{c.patient.emergencyType}</span>
                    <span className="font-mono text-[#5b6a61]">{dateStr}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* CASE DETAILS & AI INSIGHT INSPECTOR */}
        <div className="lg:col-span-2 bg-[#0d1310] border border-[#202923] rounded-2xl p-6 shadow-lg">
          {selectedCase ? (
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1f2822] pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-[#54c984]">
                      {selectedCase.id}
                    </span>
                    <span className="text-xs text-[#6e7e74]">
                      • Recorded: {new Date(selectedCase.createdAt).toLocaleString()}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-[#e1e9e4] mt-1">
                    {selectedCase.patient.name || 'Emergency Patient'}
                  </h3>
                </div>

                <button
                  onClick={() => onLoadCase(selectedCase)}
                  className="px-4 py-2 rounded-xl bg-[#237344] hover:bg-[#2b8250] text-[#f1fff6] border border-[#3f9a63] text-xs font-bold flex items-center gap-2 transition-all cursor-pointer"
                >
                  <span>LOAD INTO ACTIVE DISPATCH</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Patient & Vitals Summary */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#090f0c] p-4 rounded-xl border border-[#202a23] text-xs font-mono">
                <div>
                  <span className="text-[10px] text-[#69796f] block font-sans">EMERGENCY</span>
                  <span className="font-bold text-[#e59b58] font-sans">
                    {selectedCase.patient.emergencyType}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-[#69796f] block font-sans">BLOOD GROUP</span>
                  <span className="font-bold text-[#e1e9e4]">
                    {selectedCase.patient.bloodGroup}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-[#69796f] block font-sans">AMBULANCE</span>
                  <span className="font-bold text-[#54c984]">
                    {selectedCase.patient.ambulanceId}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-[#69796f] block font-sans">ASSIGNED DEST</span>
                  <span className="font-bold text-[#4ea1d3] truncate block font-sans">
                    {selectedCase.assignedHospitalName}
                  </span>
                </div>
              </div>

              {/* Vitals Telemetry Grid */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center text-xs font-mono">
                <div className="bg-[#090f0c] p-2.5 rounded-lg border border-[#1e2721]">
                  <span className="text-[9px] text-[#67776d] block font-sans">BP SYS</span>
                  <span className="font-bold text-[#e1e9e4]">{selectedCase.vitals.bp}</span>
                </div>
                <div className="bg-[#090f0c] p-2.5 rounded-lg border border-[#1e2721]">
                  <span className="text-[9px] text-[#67776d] block font-sans">HEART RATE</span>
                  <span className="font-bold text-[#e1e9e4]">{selectedCase.vitals.heartRate}</span>
                </div>
                <div className="bg-[#090f0c] p-2.5 rounded-lg border border-[#1e2721]">
                  <span className="text-[9px] text-[#67776d] block font-sans">SpO2</span>
                  <span className="font-bold text-[#54c984]">{selectedCase.vitals.spo2}%</span>
                </div>
                <div className="bg-[#090f0c] p-2.5 rounded-lg border border-[#1e2721]">
                  <span className="text-[9px] text-[#67776d] block font-sans">TEMP</span>
                  <span className="font-bold text-[#e1e9e4]">{selectedCase.vitals.temperature}°C</span>
                </div>
                <div className="bg-[#090f0c] p-2.5 rounded-lg border border-[#1e2721]">
                  <span className="text-[9px] text-[#67776d] block font-sans">CONSCIOUS</span>
                  <span className="font-bold text-[#e1e9e4] font-sans">{selectedCase.vitals.consciousness}</span>
                </div>
                <div className="bg-[#090f0c] p-2.5 rounded-lg border border-[#1e2721]">
                  <span className="text-[9px] text-[#67776d] block font-sans">TRAUMA</span>
                  <span className="font-bold text-[#e1e9e4] font-sans">{selectedCase.vitals.trauma}</span>
                </div>
              </div>

              {/* AI Insights & SBAR Handover */}
              {selectedCase.aiInsights && (
                <div className="space-y-3.5">
                  <div className="bg-[#09100c] border border-[#212f26] p-4 rounded-xl text-xs space-y-2">
                    <span className="text-[10px] font-bold text-[#54c984] uppercase tracking-wider block">
                      AI Diagnostic Impression:
                    </span>
                    <p className="text-[#d0ded6] leading-relaxed">
                      {selectedCase.aiInsights.clinicalImpression}
                    </p>
                  </div>

                  <div className="bg-[#080d0a] border border-[#1c2620] p-4 rounded-xl text-xs font-mono space-y-1.5">
                    <span className="text-[10px] font-bold text-[#6a7d72] uppercase tracking-wider block font-sans">
                      Recorded Hospital SBAR Handover:
                    </span>
                    <p className="text-[#9fb4a7] leading-relaxed whitespace-pre-line">
                      {selectedCase.aiInsights.hospitalHandoverProtocol}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="py-24 text-center text-xs text-[#718077]">
              Select an emergency case from the left panel to inspect full details.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
