import React from 'react';
import { Hospital } from '../types';
import { Building2, Bed, Check, X, Phone, MapPin } from 'lucide-react';
import { api } from '../services/api';

interface HospitalNetworkViewProps {
  hospitals: Hospital[];
  onRefresh: () => void;
  onCallHospital: (hospital: Hospital) => void;
}

export const HospitalNetworkView: React.FC<HospitalNetworkViewProps> = ({
  hospitals,
  onRefresh,
  onCallHospital,
}) => {
  const toggleResource = async (
    hospitalId: string,
    key: keyof Hospital,
    currentVal: boolean
  ) => {
    try {
      await api.updateHospital(hospitalId, { [key]: !currentVal });
      onRefresh();
    } catch (err) {
      console.error('Failed to toggle resource:', err);
    }
  };

  const updateCapacity = async (hospitalId: string, capacity: number) => {
    try {
      await api.updateHospital(hospitalId, { capacity });
      onRefresh();
    } catch (err) {
      console.error('Failed to update capacity:', err);
    }
  };

  const updateBeds = async (hospitalId: string, icuBedsAvailable: number) => {
    try {
      await api.updateHospital(hospitalId, { icuBedsAvailable: Math.max(0, icuBedsAvailable) });
      onRefresh();
    } catch (err) {
      console.error('Failed to update beds:', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#14261c] border border-[#327048] flex items-center justify-center text-[#54c984]">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#e1e8e4]">
              Hospital Emergency Network Matrix
            </h2>
            <p className="text-xs text-[#718077]">
              Live status, bed telemetry, resource toggles, and trauma bay allocations
            </p>
          </div>
        </div>

        <span className="text-xs font-mono px-3 py-1 rounded-lg bg-[#111c16] border border-[#233a2c] text-[#54c984]">
          Connected Centers: {hospitals.length}
        </span>
      </div>

      {/* HOSPITALS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {hospitals.map((h) => (
          <div
            key={h.id}
            className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg flex flex-col justify-between"
          >
            <div>
              {/* Header */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <div>
                  <h3 className="text-base font-bold text-[#e1e9e4]">{h.name}</h3>
                  <div className="text-xs text-[#75847b] flex items-center gap-1.5 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-[#54c984]" />
                    <span>{h.location} • {h.address}</span>
                  </div>
                </div>

                <button
                  onClick={() => onCallHospital(h)}
                  className="px-3 py-1.5 rounded-lg bg-[#16291e] hover:bg-[#1f3829] text-[#54c984] border border-[#2d5c3f] text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call Hospital</span>
                </button>
              </div>

              {/* Stats Bar */}
              <div className="grid grid-cols-3 gap-2.5 bg-[#090f0c] p-3 rounded-xl border border-[#1e2721] mb-4 text-xs font-mono">
                <div>
                  <span className="text-[10px] text-[#6a7970] block">ETA</span>
                  <span className="font-bold text-[#54c984]">{h.eta} min</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#6a7970] block">DISTANCE</span>
                  <span className="font-bold text-[#d2ded6]">{h.distance}</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#6a7970] block">OCCUPANCY</span>
                  <span className="font-bold text-amber-400">{h.capacity}%</span>
                </div>
              </div>

              {/* Bed Counters & Capacity Slider */}
              <div className="space-y-3 mb-4 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[#819488]">ICU Beds Available:</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateBeds(h.id, h.icuBedsAvailable - 1)}
                      className="w-6 h-6 rounded bg-[#17201a] border border-[#29372f] text-[#cbd7d0] hover:bg-[#202e24] flex items-center justify-center font-mono font-bold"
                    >
                      -
                    </button>
                    <span className="font-mono font-bold text-[#54c984] w-6 text-center">
                      {h.icuBedsAvailable}
                    </span>
                    <button
                      onClick={() => updateBeds(h.id, h.icuBedsAvailable + 1)}
                      className="w-6 h-6 rounded bg-[#17201a] border border-[#29372f] text-[#cbd7d0] hover:bg-[#202e24] flex items-center justify-center font-mono font-bold"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[#819488]">Capacity Load:</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="range"
                      min={10}
                      max={100}
                      value={h.capacity}
                      onChange={(e) => updateCapacity(h.id, Number(e.target.value))}
                      className="accent-[#54c984] w-28 cursor-pointer"
                    />
                    <span className="font-mono text-[#d2ded6] w-9 text-right">{h.capacity}%</span>
                  </div>
                </div>
              </div>

              {/* Resource Toggles */}
              <div>
                <div className="text-[10px] font-bold text-[#67776e] uppercase tracking-wider mb-2">
                  Specialized Facilities & Resources:
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {(
                    [
                      ['ICU', 'icu', h.icu],
                      ['OXYGEN', 'oxygen', h.oxygen],
                      ['VENTILATOR', 'ventilator', h.ventilator],
                      ['TRAUMA', 'trauma', h.trauma],
                      ['CT SCAN', 'ct', h.ct],
                      ['CARDIAC', 'cardiac', h.cardiac],
                      ['SURGERY', 'surgery', h.surgery],
                      ['SPECIALIST', 'specialist', h.specialist],
                    ] as const
                  ).map(([label, key, val]) => (
                    <button
                      key={label}
                      onClick={() => toggleResource(h.id, key, val)}
                      className={`py-1.5 px-1 rounded-lg text-[10px] font-semibold border flex items-center justify-center gap-1 transition-all ${
                        val
                          ? 'bg-[#15231c] border-[#294c37] text-[#54c984]'
                          : 'bg-[#201414] border-[#442525] text-[#b96b6b]'
                      }`}
                    >
                      {val ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                      <span>{label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="text-[11px] text-[#5c6e64] font-mono mt-4 pt-3 border-t border-[#1a231d] flex justify-between">
              <span>Emergency Desk: {h.phone}</span>
              <span className="text-[#54c984]">LIVE TELEMETRY ON</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
