import React from 'react';
import { PatientInfo, MedicalVitals, AIAnalysisResult, Hospital } from '../types';
import { Brain, AlertCircle, FileText, CheckCircle2, ShieldAlert, Sparkles, Building2 } from 'lucide-react';

interface AnalysisViewProps {
  patient: PatientInfo;
  vitals: MedicalVitals;
  aiResult: AIAnalysisResult | null;
  recommendedHospital: Hospital;
  onAnalyze: () => void;
  analyzing: boolean;
}

export const AnalysisView: React.FC<AnalysisViewProps> = ({
  patient,
  vitals,
  aiResult,
  recommendedHospital,
  onAnalyze,
  analyzing,
}) => {
  if (!aiResult) {
    return (
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-8 text-center max-w-2xl mx-auto my-12">
        <div className="w-14 h-14 rounded-2xl bg-[#14261c] border border-[#2e5d40] text-[#54c984] flex items-center justify-center mx-auto mb-4">
          <Brain className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-[#e1e8e4]">No Active Patient Analysis</h2>
        <p className="text-xs text-[#75847a] mt-2 mb-6 leading-relaxed max-w-md mx-auto">
          AMIGO integrates with Gemini AI on the backend to evaluate vital signs, calculate emergency severity, prioritize trauma resources, and provide structured SBAR handover protocols.
        </p>
        <button
          onClick={onAnalyze}
          disabled={analyzing}
          className="px-6 py-3 rounded-xl font-bold text-xs bg-[#237344] hover:bg-[#2b8250] text-[#f1fff6] border border-[#3f9a63] shadow-[0_0_15px_rgba(50,145,87,0.3)] transition-all cursor-pointer"
        >
          {analyzing ? 'ANALYZING PATIENT WITH GEMINI...' : '🧠 TRIGGER AI PATIENT ANALYSIS NOW'}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* HEADER SUMMARY CARD */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-6 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1c2620] pb-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#14281c] border border-[#34794e] flex items-center justify-center text-[#54c984]">
              <Brain className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-[#e1e8e4]">Clinical Emergency Evaluation</h2>
                <span className="text-[10px] bg-[#16271e] text-[#54c984] border border-[#2c533c] px-2 py-0.5 rounded-full font-mono">
                  Gemini 3.8 Flash
                </span>
              </div>
              <p className="text-xs text-[#75847b] mt-0.5">
                Case Telemetry for {patient.name || 'Emergency Patient'} • Ambulance {patient.ambulanceId}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 rounded-xl bg-[#090e0c] border border-[#232d27] text-right">
              <div className="text-[9px] text-[#697870] font-semibold uppercase">SEVERITY TIER</div>
              <div
                className={`text-sm font-extrabold font-mono ${
                  aiResult.severityTier === 'CRITICAL'
                    ? 'text-rose-400'
                    : aiResult.severityTier === 'URGENT'
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                {aiResult.severityTier} ({aiResult.severityScore}/100)
              </div>
            </div>

            <div className="px-4 py-2 rounded-xl bg-[#090e0c] border border-[#232d27] text-right">
              <div className="text-[9px] text-[#697870] font-semibold uppercase">ALERT LEVEL</div>
              <div className="text-sm font-bold text-rose-300 font-mono">
                {aiResult.alertLevel}
              </div>
            </div>
          </div>
        </div>

        {/* Clinical Impression */}
        <div className="mt-5 space-y-4">
          <div className="bg-[#09100c] border border-[#222e26] rounded-xl p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-[#54c984] uppercase tracking-wider mb-1.5">
              <Sparkles className="w-4 h-4" />
              <span>AI Diagnostic Synthesis & Impression</span>
            </div>
            <p className="text-xs text-[#d3ded7] leading-relaxed font-sans">
              {aiResult.clinicalImpression}
            </p>
          </div>

          {/* Vitals Summary Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 font-mono text-center">
            <div className="bg-[#090e0c] border border-[#202923] p-2 rounded-lg">
              <span className="text-[9px] text-[#6d7b73] block">BP (SYS)</span>
              <span className="text-xs font-bold text-[#e1e9e4]">{vitals.bp} mmHg</span>
            </div>
            <div className="bg-[#090e0c] border border-[#202923] p-2 rounded-lg">
              <span className="text-[9px] text-[#6d7b73] block">HEART RATE</span>
              <span className="text-xs font-bold text-[#e1e9e4]">{vitals.heartRate} BPM</span>
            </div>
            <div className="bg-[#090e0c] border border-[#202923] p-2 rounded-lg">
              <span className="text-[9px] text-[#6d7b73] block">SpO2</span>
              <span className="text-xs font-bold text-[#54c984]">{vitals.spo2}%</span>
            </div>
            <div className="bg-[#090e0c] border border-[#202923] p-2 rounded-lg">
              <span className="text-[9px] text-[#6d7b73] block">RESP RATE</span>
              <span className="text-xs font-bold text-[#e1e9e4]">{vitals.respRate} /min</span>
            </div>
            <div className="bg-[#090e0c] border border-[#202923] p-2 rounded-lg">
              <span className="text-[9px] text-[#6d7b73] block">TEMP</span>
              <span className="text-xs font-bold text-[#e1e9e4]">{vitals.temperature}°C</span>
            </div>
            <div className="bg-[#090e0c] border border-[#202923] p-2 rounded-lg">
              <span className="text-[9px] text-[#6d7b73] block">GLUCOSE</span>
              <span className="text-xs font-bold text-[#e1e9e4]">{vitals.glucose} mg/dL</span>
            </div>
            <div className="bg-[#090e0c] border border-[#202923] p-2 rounded-lg">
              <span className="text-[9px] text-[#6d7b73] block">SENSORIUM</span>
              <span className="text-xs font-bold text-[#e1e9e4]">{vitals.consciousness}</span>
            </div>
            <div className="bg-[#090e0c] border border-[#202923] p-2 rounded-lg">
              <span className="text-[9px] text-[#6d7b73] block">TRAUMA</span>
              <span className="text-xs font-bold text-[#e1e9e4]">{vitals.trauma}</span>
            </div>
          </div>
        </div>
      </div>

      {/* TWO COLUMN GRID: IN-TRANSIT DIRECTIVES & SBAR HANDOVER */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* EMT DIRECTIVES */}
        <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm font-bold text-[#e1e8e4] mb-3">
              <AlertCircle className="w-4 h-4 text-[#54c984]" />
              <span>Paramedic In-Transit Stabilization Directives</span>
            </div>
            <p className="text-xs text-[#738279] mb-4">
              AI-generated emergency interventions to perform prior to arrival at emergency department:
            </p>

            <div className="space-y-3">
              {aiResult.inTransitDirectives.map((directive, idx) => (
                <div
                  key={idx}
                  className="bg-[#090f0c] border border-[#212b24] p-3 rounded-xl flex items-start gap-3"
                >
                  <span className="w-5 h-5 rounded-full bg-[#172c1f] text-[#54c984] text-xs font-mono font-bold flex items-center justify-center shrink-0 border border-[#2f6341]">
                    {idx + 1}
                  </span>
                  <p className="text-xs text-[#ccd9d1] leading-relaxed">{directive}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Hospital Rationale */}
          <div className="mt-5 p-3.5 bg-[#09100c] border border-[#213127] rounded-xl">
            <span className="text-[10px] font-bold text-[#62b988] uppercase tracking-wider block mb-1">
              Facility Selection Justification:
            </span>
            <p className="text-xs text-[#9eb2a7] leading-relaxed">
              {aiResult.recommendedHospitalRationale}
            </p>
          </div>
        </div>

        {/* SBAR BRIEFING FOR HOSPITAL */}
        <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-sm font-bold text-[#e1e8e4]">
                <FileText className="w-4 h-4 text-[#54c984]" />
                <span>Hospital Handover Protocol (SBAR Standard)</span>
              </div>
              <span className="text-[10px] font-mono bg-[#17231c] text-[#79b990] px-2 py-0.5 rounded border border-[#294835]">
                ED Telemetry Pre-Alert
              </span>
            </div>
            <p className="text-xs text-[#738279] mb-4">
              Structured Situation, Background, Assessment, and Recommendation for the receiving trauma / resuscitation team:
            </p>

            <div className="bg-[#070b09] border border-[#1e2a22] rounded-xl p-4 font-mono text-xs text-[#b8cbbf] leading-relaxed whitespace-pre-line">
              {aiResult.hospitalHandoverProtocol}
            </div>
          </div>

          <div className="mt-5 p-3.5 bg-[#101914] border border-[#263c2f] rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Building2 className="w-4 h-4 text-[#54c984]" />
              <div>
                <span className="text-xs font-bold text-[#e1e9e4] block">
                  {recommendedHospital.name}
                </span>
                <span className="text-[11px] text-[#75887d]">
                  ETA: {recommendedHospital.eta} min • Distance: {recommendedHospital.distance}
                </span>
              </div>
            </div>
            <span className="text-xs font-bold text-[#54c984] px-2.5 py-1 bg-[#162a1e] rounded-lg border border-[#30593f]">
              PRE-ALERT SENT
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
