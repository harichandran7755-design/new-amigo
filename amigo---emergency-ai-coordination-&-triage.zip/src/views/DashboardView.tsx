import React from 'react';
import {
  PatientInfo,
  MedicalVitals,
  AIAnalysisResult,
  Hospital,
  ResourceRequirements,
} from '../types';
import {
  Brain,
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  Phone,
  BookmarkCheck,
  Save,
  Zap,
} from 'lucide-react';

interface DashboardViewProps {
  patient: PatientInfo;
  setPatient: React.Dispatch<React.SetStateAction<PatientInfo>>;
  vitals: MedicalVitals;
  setVitals: React.Dispatch<React.SetStateAction<MedicalVitals>>;
  aiResult: AIAnalysisResult | null;
  analyzing: boolean;
  onAnalyze: () => void;
  recommendedHospital: Hospital;
  backupHospital: Hospital;
  hospitals: Hospital[];
  onCallHospital: (hospital: Hospital) => void;
  onSaveCase: () => void;
  savingCase: boolean;
  onOpenAnalysisTab: () => void;
  onSelectHospital: (hospital: Hospital) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  patient,
  setPatient,
  vitals,
  setVitals,
  aiResult,
  analyzing,
  onAnalyze,
  recommendedHospital,
  backupHospital,
  hospitals,
  onCallHospital,
  onSaveCase,
  savingCase,
  onOpenAnalysisTab,
}) => {
  const loadPreset = (type: 'cardiac' | 'trauma' | 'respiratory' | 'stable') => {
    if (type === 'cardiac') {
      setPatient({
        name: 'A. Ramesh',
        age: 58,
        gender: 'Male',
        bloodGroup: 'O+',
        emergencyType: 'Cardiac Emergency',
        ambulanceId: 'AMB-204',
      });
      setVitals({
        bp: 80,
        heartRate: 125,
        spo2: 89,
        temperature: 37,
        respRate: 25,
        consciousness: 'Confused',
        trauma: 'No',
        painLevel: 9,
        glucose: 100,
      });
    } else if (type === 'trauma') {
      setPatient({
        name: 'S. Vignesh',
        age: 29,
        gender: 'Male',
        bloodGroup: 'B+',
        emergencyType: 'Trauma',
        ambulanceId: 'AMB-204',
      });
      setVitals({
        bp: 70,
        heartRate: 145,
        spo2: 93,
        temperature: 36,
        respRate: 30,
        consciousness: 'Confused',
        trauma: 'Yes',
        painLevel: 10,
        glucose: 110,
      });
    } else if (type === 'respiratory') {
      setPatient({
        name: 'P. Lakshmi',
        age: 64,
        gender: 'Female',
        bloodGroup: 'A+',
        emergencyType: 'Respiratory Emergency',
        ambulanceId: 'AMB-309',
      });
      setVitals({
        bp: 140,
        heartRate: 110,
        spo2: 82,
        temperature: 38,
        respRate: 30,
        consciousness: 'Alert',
        trauma: 'No',
        painLevel: 5,
        glucose: 140,
      });
    } else {
      setPatient({
        name: 'K. Balan',
        age: 42,
        gender: 'Male',
        bloodGroup: 'AB+',
        emergencyType: 'General Emergency',
        ambulanceId: 'AMB-118',
      });
      setVitals({
        bp: 120,
        heartRate: 75,
        spo2: 98,
        temperature: 37,
        respRate: 16,
        consciousness: 'Alert',
        trauma: 'No',
        painLevel: 2,
        glucose: 100,
      });
    }
  };

  const renderResourceBadges = (h: Hospital) => {
    const list: Array<[string, boolean]> = [
      ['ICU', h.icu],
      ['OXYGEN', h.oxygen],
      ['SPECIALIST', h.specialist],
      ['TRAUMA', h.trauma],
      ['VENTILATOR', h.ventilator],
      ['CT', h.ct],
      ['CARDIAC', h.cardiac],
      ['SURGERY', h.surgery],
    ];

    return (
      <div className="grid grid-cols-4 sm:grid-cols-4 gap-2 mt-4">
        {list.map(([label, active]) => (
          <div
            key={label}
            className={`text-center py-2 px-1 rounded-lg text-[10px] font-semibold border ${
              active
                ? 'bg-[#152019] border-[#294a36] text-[#78caa1]'
                : 'bg-[#211414] border-[#442323] text-[#c96d6d]'
            }`}
          >
            {active ? '✓' : '✕'} {label}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* QUICK PRESETS BANNER */}
      <div className="bg-[#0e1612] border border-[#213528] rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
        <div className="flex items-center gap-2 text-xs text-[#a0b5a8]">
          <Zap className="w-4 h-4 text-[#54c984]" />
          <span className="font-semibold text-[#dfe9e3]">Quick Emergency Simulation Presets:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => loadPreset('cardiac')}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#261616] hover:bg-[#341d1d] text-[#ff8e8e] border border-[#632929] transition-colors"
          >
            Acute STEMI / Shock
          </button>
          <button
            onClick={() => loadPreset('trauma')}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#281b10] hover:bg-[#3a2614] text-[#f7ad6a] border border-[#684120] transition-colors"
          >
            Polytrauma / MVA
          </button>
          <button
            onClick={() => loadPreset('respiratory')}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#1a2319] hover:bg-[#233122] text-[#86d49f] border border-[#345c3d] transition-colors"
          >
            Respiratory Failure
          </button>
          <button
            onClick={() => loadPreset('stable')}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#121a15] hover:bg-[#1a261f] text-[#889990] border border-[#25362c] transition-colors"
          >
            Stable Triage
          </button>
        </div>
      </div>

      {/* PATIENT DETAILS */}
      <div className="bg-[#0d1310] border border-[#202923] border-l-4 border-l-[#3d8f60] rounded-2xl p-5 shadow-lg">
        <div className="text-base font-bold text-[#e1e8e4] mb-4 flex items-center gap-2">
          <span>👤 Patient Details</span>
          <span className="text-xs font-normal text-[#6f8076]">
            (Ambulance Ingress Telemetry)
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              PATIENT NAME
            </label>
            <input
              type="text"
              value={patient.name}
              onChange={(e) => setPatient({ ...patient, name: e.target.value })}
              placeholder="Enter patient name"
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            />
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              AGE
            </label>
            <input
              type="number"
              value={patient.age || ''}
              onChange={(e) =>
                setPatient({ ...patient, age: Number(e.target.value) || 0 })
              }
              placeholder="Age"
              min={0}
              max={120}
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            />
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              GENDER
            </label>
            <select
              value={patient.gender}
              onChange={(e) => setPatient({ ...patient, gender: e.target.value })}
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option>Male</option>
              <option>Female</option>
              <option>Other</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              BLOOD GROUP
            </label>
            <select
              value={patient.bloodGroup}
              onChange={(e) =>
                setPatient({ ...patient, bloodGroup: e.target.value })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option>O+</option>
              <option>O-</option>
              <option>A+</option>
              <option>A-</option>
              <option>B+</option>
              <option>B-</option>
              <option>AB+</option>
              <option>AB-</option>
              <option>Unknown</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              EMERGENCY TYPE
            </label>
            <select
              value={patient.emergencyType}
              onChange={(e) =>
                setPatient({ ...patient, emergencyType: e.target.value })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option>Cardiac Emergency</option>
              <option>Trauma</option>
              <option>Respiratory Emergency</option>
              <option>Neurological Emergency</option>
              <option>General Emergency</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              AMBULANCE ID
            </label>
            <input
              type="text"
              value={patient.ambulanceId}
              onChange={(e) =>
                setPatient({ ...patient, ambulanceId: e.target.value })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs font-mono focus:outline-none focus:border-[#4b8d65]"
            />
          </div>
        </div>
      </div>

      {/* MEDICAL DETAILS / VITALS */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg">
        <div className="text-base font-bold text-[#e1e8e4] mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span>🩺 Patient Medical Details & Vital Signs</span>
          </div>
          <span className="text-xs text-[#6e7d74] font-mono">
            Paramedic Telemetry Sensor Feed
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              BLOOD PRESSURE (SYSTOLIC)
            </label>
            <select
              value={vitals.bp}
              onChange={(e) =>
                setVitals({ ...vitals, bp: Number(e.target.value) })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option value="120">120 mmHg - Normal</option>
              <option value="100">100 mmHg</option>
              <option value="90">90 mmHg - Borderline</option>
              <option value="80">80 mmHg - Low / Shock Risk</option>
              <option value="70">70 mmHg - Critical Hypotension</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              HEART RATE
            </label>
            <select
              value={vitals.heartRate}
              onChange={(e) =>
                setVitals({ ...vitals, heartRate: Number(e.target.value) })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option value="75">75 BPM - Normal</option>
              <option value="90">90 BPM</option>
              <option value="110">110 BPM - Tachycardia</option>
              <option value="125">125 BPM - High</option>
              <option value="145">145 BPM - Critical</option>
              <option value="45">45 BPM - Severe Bradycardia</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              SpO₂ (OXYGEN SATURATION)
            </label>
            <select
              value={vitals.spo2}
              onChange={(e) =>
                setVitals({ ...vitals, spo2: Number(e.target.value) })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option value="98">98% - Normal</option>
              <option value="95">95%</option>
              <option value="93">93% - Low</option>
              <option value="89">89% - Critical Hypoxia</option>
              <option value="82">82% - Severe Respiratory Failure</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              TEMPERATURE
            </label>
            <select
              value={vitals.temperature}
              onChange={(e) =>
                setVitals({ ...vitals, temperature: Number(e.target.value) })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option value="37">37°C - Normal</option>
              <option value="38">38°C - Mild Fever</option>
              <option value="39">39°C - High</option>
              <option value="40">40°C - Critical Hyperthermia</option>
              <option value="34">34°C - Hypothermia</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              RESPIRATORY RATE
            </label>
            <select
              value={vitals.respRate}
              onChange={(e) =>
                setVitals({ ...vitals, respRate: Number(e.target.value) })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option value="16">16 /min - Normal</option>
              <option value="20">20 /min</option>
              <option value="25">25 /min - Tachypnea</option>
              <option value="30">30 /min - Critical</option>
              <option value="8">8 /min - Bradypnea / Arrest</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              CONSCIOUSNESS
            </label>
            <select
              value={vitals.consciousness}
              onChange={(e) =>
                setVitals({ ...vitals, consciousness: e.target.value })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option>Alert</option>
              <option>Confused</option>
              <option>Unconscious</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              TRAUMA PRESENT
            </label>
            <select
              value={vitals.trauma}
              onChange={(e) =>
                setVitals({ ...vitals, trauma: e.target.value })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option>No</option>
              <option>Yes</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              PAIN LEVEL (0 - 10)
            </label>
            <select
              value={vitals.painLevel}
              onChange={(e) =>
                setVitals({ ...vitals, painLevel: Number(e.target.value) })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option value="2">2 / 10 - Mild</option>
              <option value="5">5 / 10 - Moderate</option>
              <option value="7">7 / 10 - High</option>
              <option value="9">9 / 10 - Severe</option>
              <option value="10">10 / 10 - Critical / Maximum</option>
            </select>
          </div>

          <div className="sm:col-span-2 md:col-span-1 lg:col-span-4">
            <label className="block text-[11px] text-[#747f79] mb-1.5 font-semibold">
              BLOOD GLUCOSE
            </label>
            <select
              value={vitals.glucose}
              onChange={(e) =>
                setVitals({ ...vitals, glucose: Number(e.target.value) })
              }
              className="w-full px-3 py-2.5 bg-[#090e0c] text-[#dfe6e2] border border-[#252e29] rounded-xl text-xs focus:outline-none focus:border-[#4b8d65]"
            >
              <option value="100">100 mg/dL - Normal</option>
              <option value="70">70 mg/dL</option>
              <option value="55">55 mg/dL - Hypoglycemia</option>
              <option value="250">250 mg/dL - Hyperglycemia</option>
              <option value="350">350 mg/dL - Critical DKA Risk</option>
            </select>
          </div>
        </div>

        {/* ANALYZE BUTTON */}
        <button
          onClick={onAnalyze}
          disabled={analyzing}
          className="w-full mt-5 py-4 rounded-xl font-bold text-sm bg-[#237344] hover:bg-[#2b8250] text-[#f1fff6] border border-[#3f9a63] shadow-[0_0_20px_rgba(50,145,87,0.22)] flex items-center justify-center gap-2.5 transition-all disabled:opacity-50 cursor-pointer"
        >
          <Brain className={`w-5 h-5 ${analyzing ? 'animate-spin' : ''}`} />
          <span>
            {analyzing
              ? 'AMIGO AI ANALYZING VITALS WITH GEMINI 3.8 FLASH...'
              : '🧠 ANALYZE PATIENT & FIND BEST HOSPITAL'}
          </span>
        </button>
      </div>

      {/* AI RESULT SECTION */}
      {aiResult && (
        <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-base font-bold text-[#e1e8e4] flex items-center gap-2">
              <span>🤖 AMIGO AI Patient Analysis & Insights</span>
              <span className="text-xs bg-[#16271e] text-[#54c984] border border-[#2f553f] px-2.5 py-0.5 rounded-full font-mono">
                Powered by Gemini 3.8 Flash Backend
              </span>
            </div>

            {/* Save Case Button */}
            <button
              onClick={onSaveCase}
              disabled={savingCase}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-[#17271e] hover:bg-[#21382b] text-[#60d694] border border-[#325b42] transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{savingCase ? 'Saving to DB...' : 'Save Case to Database'}</span>
            </button>
          </div>

          {/* Severity Banner */}
          <div
            className={`p-4 rounded-xl border flex items-center justify-between ${
              aiResult.severityTier === 'CRITICAL'
                ? 'bg-[#241313] border-[#a63d3d] text-[#ed7777]'
                : aiResult.severityTier === 'URGENT'
                ? 'bg-[#241d0e] border-[#a47c32] text-[#d7ad58]'
                : 'bg-[#102018] border-[#397454] text-[#72b88d]'
            }`}
          >
            <div className="flex items-center gap-3">
              {aiResult.severityTier === 'CRITICAL' ? (
                <ShieldAlert className="w-8 h-8 text-[#ff6868]" />
              ) : aiResult.severityTier === 'URGENT' ? (
                <AlertTriangle className="w-8 h-8 text-[#f0ba4d]" />
              ) : (
                <ShieldCheck className="w-8 h-8 text-[#54c984]" />
              )}
              <div>
                <h2 className="text-xl font-black tracking-wide">
                  {aiResult.severityTier} EMERGENCY
                </h2>
                <div className="text-xs opacity-90 mt-0.5">
                  AMIGO Emergency Severity Index: <b>{aiResult.severityScore}/100</b> • Alert Level: <b>{aiResult.alertLevel}</b>
                </div>
              </div>
            </div>

            <button
              onClick={onOpenAnalysisTab}
              className="hidden sm:block text-xs font-semibold px-3 py-1.5 rounded-lg bg-black/30 border border-current hover:bg-black/50 transition-colors"
            >
              View Full Clinical Brief →
            </button>
          </div>

          {/* Clinical Impression & Critical Risks */}
          <div className="bg-[#09100c] border border-[#222c25] rounded-xl p-4 text-xs space-y-2.5">
            <div className="text-[#a5b5ab]">
              <span className="font-bold text-[#54c984] uppercase tracking-wider text-[11px] block mb-1">
                Clinical Impression:
              </span>
              <p className="leading-relaxed text-[#d7e2dc]">{aiResult.clinicalImpression}</p>
            </div>

            {aiResult.criticalRisks && aiResult.criticalRisks.length > 0 && (
              <div className="border-t border-[#1d2720] pt-2">
                <span className="font-bold text-rose-400 uppercase tracking-wider text-[10px] block mb-1">
                  Immediate Life Threats & Critical Risks:
                </span>
                <ul className="list-disc list-inside space-y-1 text-[#e0a8a8]">
                  {aiResult.criticalRisks.map((risk, idx) => (
                    <li key={idx}>{risk}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Required Emergency Resources Grid */}
          <div>
            <div className="text-xs font-bold text-[#7d8d83] uppercase tracking-wider mb-2">
              Mandatory Hospital Resources Identified by AI:
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
              {Object.entries(aiResult.requiredResources).map(
                ([key, required]) => (
                  <div
                    key={key}
                    className={`p-3 rounded-xl text-center border transition-all ${
                      required
                        ? 'bg-[#211111] border-[#8e3838] text-[#e5b1b1]'
                        : 'bg-[#101713] border-[#29352e] text-[#aebbb4]'
                    }`}
                  >
                    <div className="text-[11px] font-semibold">{key}</div>
                    <strong
                      className={`block text-[10px] mt-1 ${
                        required ? 'text-[#ff6868]' : 'text-[#70b58a]'
                      }`}
                    >
                      {required ? 'REQUIRED' : 'NOT NEEDED'}
                    </strong>
                  </div>
                )
              )}
            </div>
          </div>
        </div>
      )}

      {/* HOSPITAL COORDINATION SECTION */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg space-y-5">
        <div className="flex items-center justify-between border-b border-[#202923] pb-4">
          <div>
            <h2 className="text-base font-bold text-[#e1e8e4]">
              🏥 Hospital Coordination & Resource Dispatch
            </h2>
            <p className="text-xs text-[#707c75] mt-0.5">
              Live matching ambulance {patient.ambulanceId} with receiving facility
            </p>
          </div>
          <div className="px-3 py-1 rounded-lg bg-[#17231c] text-[#79b990] text-xs font-mono font-bold border border-[#304b39]">
            AMIGO READY
          </div>
        </div>

        {/* RECOMMENDED & BACKUP HOSPITALS */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* RECOMMENDED */}
          <div className="bg-[#101613] border border-[#4a9465] rounded-2xl p-5 shadow-[0_0_20px_rgba(55,135,83,0.08)] flex flex-col justify-between">
            <div>
              <span className="inline-block px-2.5 py-1 rounded-md bg-[#18251d] text-[#79b990] text-[10px] font-extrabold uppercase tracking-wider mb-2.5">
                ★ AMIGO RECOMMENDED HOSPITAL
              </span>
              <h3 className="text-xl font-bold text-[#e3e9e6]">
                {recommendedHospital.name}
              </h3>
              <p className="text-xs text-[#75817a] mt-0.5">
                {recommendedHospital.location} • {recommendedHospital.address}
              </p>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-2.5 mt-4">
                <div className="bg-[#090e0c] border border-[#242d28] p-2.5 rounded-xl">
                  <div className="text-[9px] text-[#6d7772] font-semibold uppercase">
                    ETA
                  </div>
                  <div className="text-sm font-bold text-[#54c984] font-mono">
                    {recommendedHospital.eta} min
                  </div>
                </div>

                <div className="bg-[#090e0c] border border-[#242d28] p-2.5 rounded-xl">
                  <div className="text-[9px] text-[#6d7772] font-semibold uppercase">
                    DISTANCE
                  </div>
                  <div className="text-sm font-bold text-[#d9e3de] font-mono">
                    {recommendedHospital.distance}
                  </div>
                </div>

                <div className="bg-[#090e0c] border border-[#242d28] p-2.5 rounded-xl">
                  <div className="text-[9px] text-[#6d7772] font-semibold uppercase">
                    CAPACITY
                  </div>
                  <div className="text-sm font-bold text-[#d9e3de] font-mono">
                    {recommendedHospital.capacity}%
                  </div>
                </div>
              </div>

              {/* Resources */}
              {renderResourceBadges(recommendedHospital)}
            </div>

            <button
              onClick={() => onCallHospital(recommendedHospital)}
              className="w-full mt-5 py-3.5 px-4 rounded-xl font-bold text-xs bg-[#237344] hover:bg-[#2b8250] text-[#f1fff6] border border-[#3f9a63] shadow-[0_0_14px_rgba(50,145,87,0.25)] flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Phone className="w-4 h-4" />
              <span>📞 CALL RECOMMENDED HOSPITAL</span>
            </button>
          </div>

          {/* BACKUP */}
          <div className="bg-[#101613] border border-[#303b34] rounded-2xl p-5 flex flex-col justify-between">
            <div>
              <span className="inline-block px-2.5 py-1 rounded-md bg-[#171d19] text-[#9aa9a1] text-[10px] font-extrabold uppercase tracking-wider mb-2.5">
                ◈ BACKUP HOSPITAL
              </span>
              <h3 className="text-xl font-bold text-[#e3e9e6]">
                {backupHospital.name}
              </h3>
              <p className="text-xs text-[#75817a] mt-0.5">
                {backupHospital.location} • {backupHospital.address}
              </p>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-2.5 mt-4">
                <div className="bg-[#090e0c] border border-[#242d28] p-2.5 rounded-xl">
                  <div className="text-[9px] text-[#6d7772] font-semibold uppercase">
                    ETA
                  </div>
                  <div className="text-sm font-bold text-[#b7c7be] font-mono">
                    {backupHospital.eta} min
                  </div>
                </div>

                <div className="bg-[#090e0c] border border-[#242d28] p-2.5 rounded-xl">
                  <div className="text-[9px] text-[#6d7772] font-semibold uppercase">
                    DISTANCE
                  </div>
                  <div className="text-sm font-bold text-[#d9e3de] font-mono">
                    {backupHospital.distance}
                  </div>
                </div>

                <div className="bg-[#090e0c] border border-[#242d28] p-2.5 rounded-xl">
                  <div className="text-[9px] text-[#6d7772] font-semibold uppercase">
                    CAPACITY
                  </div>
                  <div className="text-sm font-bold text-[#d9e3de] font-mono">
                    {backupHospital.capacity}%
                  </div>
                </div>
              </div>

              {/* Resources */}
              {renderResourceBadges(backupHospital)}
            </div>

            <button
              onClick={() => onCallHospital(backupHospital)}
              className="w-full mt-5 py-3.5 px-4 rounded-xl font-bold text-xs bg-[#151e19] hover:bg-[#1c2721] text-[#b9c9c0] border border-[#34443b] flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Phone className="w-4 h-4" />
              <span>📞 CALL BACKUP HOSPITAL</span>
            </button>
          </div>
        </div>

        {/* TELEMETRY CONNECTION & HOSPITAL RESPONSE PANELS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <div className="bg-[#090f0c] border border-[#242d28] rounded-xl p-4 text-xs space-y-2.5">
            <div className="text-[#78847d] font-bold text-[11px] uppercase tracking-wider mb-2">
              📞 SELECTED HOSPITAL COMMUNICATION
            </div>
            <div className="flex justify-between py-1 border-b border-[#1a211d]">
              <span className="text-[#707b75]">Hospital:</span>
              <span className="font-semibold text-[#d9e3de]">{recommendedHospital.name}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1a211d]">
              <span className="text-[#707b75]">Connection:</span>
              <span className="font-semibold text-[#54c984]">Encrypted Channel Ready</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1a211d]">
              <span className="text-[#707b75]">Patient:</span>
              <span className="font-semibold text-[#d9e3de]">
                {patient.name || 'Not analyzed'}
              </span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#707b75]">Reservation:</span>
              <span className="font-semibold text-amber-400">Ready to Lock</span>
            </div>
          </div>

          <div className="bg-[#090f0c] border border-[#242d28] rounded-xl p-4 text-xs space-y-2.5">
            <div className="text-[#78847d] font-bold text-[11px] uppercase tracking-wider mb-2">
              📡 HOSPITAL RESPONSE TELEMETRY
            </div>
            <div className="flex justify-between py-1 border-b border-[#1a211d]">
              <span className="text-[#707b75]">Resource Status:</span>
              <span className="font-semibold text-[#70b58a]">Available & Standby</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1a211d]">
              <span className="text-[#707b75]">ICU Beds Available:</span>
              <span className="font-semibold text-[#d9e3de]">
                {recommendedHospital.icuBedsAvailable} Beds Open
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1a211d]">
              <span className="text-[#707b75]">Emergency Team:</span>
              <span className="font-semibold text-[#54c984]">On Standby</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#707b75]">AMIGO Dispatch:</span>
              <span className="font-semibold text-[#54c984]">Ready</span>
            </div>
          </div>
        </div>
      </div>

      {/* HOSPITAL NETWORK TABLE */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg">
        <div className="text-base font-bold text-[#e1e8e4] mb-3 flex items-center justify-between">
          <span>🏥 Hospital Network Overview</span>
          <span className="text-xs text-[#6e7d74]">Salem Emergency District</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1d2721] text-[#737f78]">
                <th className="py-3 px-3">Hospital</th>
                <th className="py-3 px-3">ETA</th>
                <th className="py-3 px-3">Distance</th>
                <th className="py-3 px-3">ICU</th>
                <th className="py-3 px-3">Oxygen</th>
                <th className="py-3 px-3">Capacity</th>
                <th className="py-3 px-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {hospitals.map((h) => {
                const isRecommended = h.id === recommendedHospital.id;
                const isBackup = h.id === backupHospital.id;
                return (
                  <tr
                    key={h.id}
                    className="border-b border-[#1d2721] text-[#d2dcd7] hover:bg-[#121915]"
                  >
                    <td className="py-3 px-3 font-semibold text-[#e1e8e4]">{h.name}</td>
                    <td className="py-3 px-3 font-mono">{h.eta} min</td>
                    <td className="py-3 px-3 font-mono">{h.distance}</td>
                    <td className="py-3 px-3">
                      <span className={h.icu ? 'text-[#54c984]' : 'text-[#888]'}>
                        {h.icu ? 'YES' : 'NO'}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className={h.oxygen ? 'text-[#54c984]' : 'text-[#888]'}>
                        {h.oxygen ? 'YES' : 'NO'}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono">{h.capacity}%</td>
                    <td className="py-3 px-3">
                      {isRecommended ? (
                        <span className="text-[#54c984] font-bold">★ RECOMMENDED</span>
                      ) : isBackup ? (
                        <span className="text-[#98a69e] font-semibold">◈ BACKUP</span>
                      ) : (
                        <span className="text-[#64756b]">AVAILABLE</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
