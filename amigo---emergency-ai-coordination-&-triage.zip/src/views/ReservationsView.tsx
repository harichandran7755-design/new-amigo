import React, { useState } from 'react';
import { Reservation, Hospital } from '../types';
import { Lock, Plus, CheckCircle, XCircle, Clock, Building2 } from 'lucide-react';
import { api } from '../services/api';

interface ReservationsViewProps {
  reservations: Reservation[];
  hospitals: Hospital[];
  onRefresh: () => void;
}

export const ReservationsView: React.FC<ReservationsViewProps> = ({
  reservations,
  hospitals,
  onRefresh,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newRes, setNewRes] = useState({
    hospitalName: hospitals[0]?.name || 'CityCare Emergency Hospital',
    resourceType: 'ICU Bed & Trauma Bay',
    patientName: '',
    ambulanceId: 'AMB-204',
    eta: '7 min',
    notes: 'Urgent bed allocation requested',
  });

  const handleCreateReservation = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const selectedHosp = hospitals.find((h) => h.name === newRes.hospitalName) || hospitals[0];
      await api.createReservation({
        ...newRes,
        hospitalId: selectedHosp.id,
      });
      setShowAddModal(false);
      setNewRes({
        hospitalName: hospitals[0]?.name || 'CityCare Emergency Hospital',
        resourceType: 'ICU Bed & Trauma Bay',
        patientName: '',
        ambulanceId: 'AMB-204',
        eta: '7 min',
        notes: '',
      });
      onRefresh();
    } catch (err) {
      console.error('Failed to create reservation:', err);
    }
  };

  const handleUpdateStatus = async (id: string, status: Reservation['status']) => {
    try {
      await api.updateReservation(id, { status });
      onRefresh();
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteReservation(id);
      onRefresh();
    } catch (err) {
      console.error('Failed to cancel reservation:', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#14261c] border border-[#327048] flex items-center justify-center text-[#54c984]">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#e1e8e4]">
              Active Hospital Resource Locks & Reservations
            </h2>
            <p className="text-xs text-[#718077]">
              Pre-allocating ICU beds, cath labs, trauma bays, and CT scanners ahead of arrival
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#237344] hover:bg-[#2b8250] text-[#f1fff6] border border-[#3f9a63] text-xs font-semibold shadow-[0_0_12px_rgba(50,145,87,0.25)] transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Reservation</span>
        </button>
      </div>

      {/* RESERVATIONS TABLE */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg">
        {reservations.length === 0 ? (
          <div className="py-12 text-center text-xs text-[#738279]">
            No active reservations found.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#1d2721] text-[#737f78]">
                  <th className="py-3 px-3">Reservation ID</th>
                  <th className="py-3 px-3">Hospital</th>
                  <th className="py-3 px-3">Locked Resource</th>
                  <th className="py-3 px-3">Patient & Unit</th>
                  <th className="py-3 px-3">ETA</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {reservations.map((res) => (
                  <tr
                    key={res.id}
                    className="border-b border-[#1d2721] text-[#d2dcd7] hover:bg-[#121915]"
                  >
                    <td className="py-3.5 px-3 font-mono font-bold text-[#e1e9e4]">
                      {res.id}
                    </td>
                    <td className="py-3.5 px-3 font-semibold text-[#dfe6e2]">
                      {res.hospitalName}
                    </td>
                    <td className="py-3.5 px-3 text-[#54c984] font-medium">
                      {res.resourceType}
                    </td>
                    <td className="py-3.5 px-3">
                      <div className="font-semibold text-[#dfe6e2]">{res.patientName}</div>
                      <div className="text-[10px] text-[#6d7c73] font-mono">{res.ambulanceId}</div>
                    </td>
                    <td className="py-3.5 px-3 font-mono text-[#54c984]">
                      {res.eta}
                    </td>
                    <td className="py-3.5 px-3">
                      <span
                        className={`inline-block px-2.5 py-1 rounded-md text-[10px] font-mono font-bold border ${
                          res.status === 'RESERVED'
                            ? 'bg-[#15231c] border-[#294c37] text-[#54c984] animate-pulse'
                            : res.status === 'ADMITTED'
                            ? 'bg-[#151e28] border-[#2d4763] text-cyan-300'
                            : res.status === 'COMPLETED'
                            ? 'bg-[#121a15] border-[#26372d] text-[#84978d]'
                            : 'bg-[#251515] border-[#4c2424] text-rose-300'
                        }`}
                      >
                        {res.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {res.status === 'RESERVED' && (
                          <button
                            onClick={() => handleUpdateStatus(res.id, 'ADMITTED')}
                            className="px-2 py-1 rounded bg-[#172635] hover:bg-[#20364c] text-cyan-300 border border-[#2b4b6d] text-[10px] font-mono"
                          >
                            Admit
                          </button>
                        )}
                        <button
                          onClick={() => handleDelete(res.id)}
                          className="px-2 py-1 rounded bg-[#201414] hover:bg-[#311c1c] text-rose-400 border border-[#482828] text-[10px] font-mono"
                        >
                          Cancel
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* CREATE MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0d1310] border border-[#2f4236] rounded-2xl p-6 shadow-2xl">
            <h3 className="text-base font-bold text-[#e1e9e4] mb-4">
              Lock Emergency Hospital Resource
            </h3>
            <form onSubmit={handleCreateReservation} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] text-[#78887e] mb-1 font-semibold">
                  HOSPITAL
                </label>
                <select
                  value={newRes.hospitalName}
                  onChange={(e) => setNewRes({ ...newRes, hospitalName: e.target.value })}
                  className="w-full px-3 py-2 bg-[#090e0c] text-[#dfe6e2] border border-[#242d27] rounded-xl focus:outline-none focus:border-[#4b8d65]"
                >
                  {hospitals.map((h) => (
                    <option key={h.id} value={h.name}>
                      {h.name} (ETA: {h.eta} min)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-[#78887e] mb-1 font-semibold">
                  RESOURCE TO RESERVE
                </label>
                <select
                  value={newRes.resourceType}
                  onChange={(e) => setNewRes({ ...newRes, resourceType: e.target.value })}
                  className="w-full px-3 py-2 bg-[#090e0c] text-[#dfe6e2] border border-[#242d27] rounded-xl focus:outline-none focus:border-[#4b8d65]"
                >
                  <option>ICU Bed & Trauma Bay</option>
                  <option>Emergency Ventilator & Intubation Suite</option>
                  <option>Interventional Cardiac Cath Lab</option>
                  <option>Emergency CT & Radiology Suite</option>
                  <option>Emergency Surgical OR Suite</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-[#78887e] mb-1 font-semibold">
                  PATIENT NAME
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. A. Ramesh"
                  value={newRes.patientName}
                  onChange={(e) => setNewRes({ ...newRes, patientName: e.target.value })}
                  className="w-full px-3 py-2 bg-[#090e0c] text-[#dfe6e2] border border-[#242d27] rounded-xl focus:outline-none focus:border-[#4b8d65]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-[#78887e] mb-1 font-semibold">
                    AMBULANCE ID
                  </label>
                  <input
                    type="text"
                    value={newRes.ambulanceId}
                    onChange={(e) => setNewRes({ ...newRes, ambulanceId: e.target.value })}
                    className="w-full px-3 py-2 bg-[#090e0c] text-[#dfe6e2] border border-[#242d27] rounded-xl font-mono focus:outline-none focus:border-[#4b8d65]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#78887e] mb-1 font-semibold">
                    ETA
                  </label>
                  <input
                    type="text"
                    value={newRes.eta}
                    onChange={(e) => setNewRes({ ...newRes, eta: e.target.value })}
                    className="w-full px-3 py-2 bg-[#090e0c] text-[#dfe6e2] border border-[#242d27] rounded-xl font-mono focus:outline-none focus:border-[#4b8d65]"
                  />
                </div>
              </div>

              <div className="flex gap-2.5 pt-3">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl font-bold text-xs bg-[#237344] hover:bg-[#2b8250] text-[#f1fff6] border border-[#3f9a63] transition-all"
                >
                  CONFIRM RESERVATION
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="py-2.5 px-4 rounded-xl text-xs bg-[#151d19] border border-[#303c34] text-[#a4b5ac] hover:bg-[#1c2721]"
                >
                  CANCEL
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
