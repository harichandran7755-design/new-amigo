import React from 'react';
import { Hospital } from '../types';
import { Activity, ShieldCheck, AlertCircle } from 'lucide-react';

interface ResourceStatusViewProps {
  hospitals: Hospital[];
}

export const ResourceStatusView: React.FC<ResourceStatusViewProps> = ({ hospitals }) => {
  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#14261c] border border-[#327048] flex items-center justify-center text-[#54c984]">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#e1e8e4]">
              Hospital Resource Capacity & Surge Telemetry
            </h2>
            <p className="text-xs text-[#718077]">
              Real-time resource load gauges, ventilator saturation, and ICU bed availability
            </p>
          </div>
        </div>
      </div>

      {/* CARDS LIST */}
      <div className="space-y-4">
        {hospitals.map((h) => {
          const isHighSurge = h.capacity >= 80;
          return (
            <div
              key={h.id}
              className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg"
            >
              <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                <div>
                  <h3 className="text-base font-bold text-[#e1e9e4]">{h.name}</h3>
                  <p className="text-xs text-[#738379]">{h.location} • ETA {h.eta} min</p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-[#697970] block uppercase font-semibold">
                      SURGE OCCUPANCY
                    </span>
                    <span
                      className={`text-sm font-mono font-bold ${
                        isHighSurge ? 'text-rose-400' : 'text-[#54c984]'
                      }`}
                    >
                      {h.capacity}%
                    </span>
                  </div>
                  <div
                    className={`px-3 py-1 rounded-lg text-xs font-semibold border ${
                      isHighSurge
                        ? 'bg-[#291717] border-[#552c2c] text-rose-300'
                        : 'bg-[#15241c] border-[#294c37] text-[#54c984]'
                    }`}
                  >
                    {isHighSurge ? 'HIGH SURGE' : 'ACCEPTING TRAFFIC'}
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-3 bg-[#17201b] rounded-full overflow-hidden mb-4 border border-[#222e26]">
                <div
                  className={`h-full transition-all duration-500 ${
                    isHighSurge
                      ? 'bg-gradient-to-r from-amber-500 to-rose-500'
                      : 'bg-gradient-to-r from-[#296f46] to-[#54c984]'
                  }`}
                  style={{ width: `${h.capacity}%` }}
                />
              </div>

              {/* Resource Badges Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="bg-[#090f0c] border border-[#212b25] p-2.5 rounded-xl flex items-center justify-between">
                  <span className="text-[#84958a]">ICU Beds:</span>
                  <span className="font-mono font-bold text-[#54c984]">
                    {h.icuBedsAvailable} Open
                  </span>
                </div>

                <div className="bg-[#090f0c] border border-[#212b25] p-2.5 rounded-xl flex items-center justify-between">
                  <span className="text-[#84958a]">Ventilators:</span>
                  <span className="font-mono font-bold text-[#54c984]">
                    {h.ventilator ? `${h.ventilatorsAvailable} Ready` : 'None'}
                  </span>
                </div>

                <div className="bg-[#090f0c] border border-[#212b25] p-2.5 rounded-xl flex items-center justify-between">
                  <span className="text-[#84958a]">Oxygen Plant:</span>
                  <span className="font-mono font-bold text-[#54c984]">
                    {h.oxygen ? 'Nominal 100%' : 'Low Supply'}
                  </span>
                </div>

                <div className="bg-[#090f0c] border border-[#212b25] p-2.5 rounded-xl flex items-center justify-between">
                  <span className="text-[#84958a]">Trauma OR:</span>
                  <span className="font-mono font-bold text-[#54c984]">
                    {h.surgery ? 'Scrubbed & Ready' : 'Unavailable'}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
