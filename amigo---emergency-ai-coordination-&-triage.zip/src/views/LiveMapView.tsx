import React, { useState, useEffect } from 'react';
import { Hospital, Ambulance } from '../types';
import { Navigation, Compass, Gauge, Radio, Shield, MapPin } from 'lucide-react';

interface LiveMapViewProps {
  recommendedHospital: Hospital;
  ambulances: Ambulance[];
  hospitals: Hospital[];
}

export const LiveMapView: React.FC<LiveMapViewProps> = ({
  recommendedHospital,
  ambulances,
  hospitals,
}) => {
  const [selectedAmbulance, setSelectedAmbulance] = useState<Ambulance>(
    ambulances[0] || {
      id: 'AMB-204',
      status: 'EN ROUTE',
      driverName: 'K. Murugan',
      paramedic: 'Dr. Sarah Paul',
      speed: '64 km/h',
      eta: '7 min',
      location: 'Salem West Bypass',
      destination: 'CityCare Emergency Hospital',
      patientName: 'A. Ramesh',
      lat: 11.652,
      lng: 78.132,
    }
  );

  const [ambProgress, setAmbProgress] = useState(35);

  useEffect(() => {
    // Subtle simulation of ambulance movement along route
    const interval = setInterval(() => {
      setAmbProgress((prev) => (prev >= 60 ? 30 : prev + 0.5));
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {/* MAP CONTROLS & TELEMETRY STRIP */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#14261c] border border-[#327048] flex items-center justify-center text-[#54c984]">
            <Navigation className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-[#e1e9e4]">
              Tactical GPS Tracking & In-Transit Radar
            </h2>
            <p className="text-xs text-[#718077]">
              Salem District Emergency Logistics Grid • Frequency: 154.280 MHz
            </p>
          </div>
        </div>

        {/* Telemetry chips */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-[#090e0c] border border-[#222c25] px-3 py-1.5 rounded-xl text-xs">
            <Gauge className="w-4 h-4 text-[#54c984]" />
            <span className="text-[#75847a]">Ground Speed:</span>
            <span className="font-mono font-bold text-[#e1e9e4]">
              {selectedAmbulance.speed || '64 km/h'}
            </span>
          </div>

          <div className="flex items-center gap-2 bg-[#090e0c] border border-[#222c25] px-3 py-1.5 rounded-xl text-xs">
            <Compass className="w-4 h-4 text-[#54c984]" />
            <span className="text-[#75847a]">Heading:</span>
            <span className="font-mono font-bold text-[#e1e9e4]">NE 42° (Bypass)</span>
          </div>

          <div className="flex items-center gap-2 bg-[#090e0c] border border-[#222c25] px-3 py-1.5 rounded-xl text-xs">
            <Radio className="w-4 h-4 text-[#54c984] animate-pulse" />
            <span className="text-[#75847a]">GPS Lock:</span>
            <span className="font-mono font-bold text-[#54c984]">14 Satellites</span>
          </div>
        </div>
      </div>

      {/* MAP CANVAS */}
      <div className="bg-[#0d1310] border border-[#202923] rounded-2xl p-5 shadow-lg relative overflow-hidden">
        <div className="h-[480px] w-full rounded-xl relative overflow-hidden bg-[#070d0a] border border-[#1b251f]">
          {/* Tactical Grid Background */}
          <div
            className="absolute inset-0 opacity-40 pointer-events-none"
            style={{
              backgroundImage: `
                linear-gradient(to right, #1b2720 1px, transparent 1px),
                linear-gradient(to bottom, #1b2720 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px',
            }}
          />

          {/* Radar Sweep Animation */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full border border-[#244130]/30 pointer-events-none">
            <div className="absolute inset-8 rounded-full border border-[#244130]/20" />
            <div className="absolute inset-20 rounded-full border border-[#244130]/15" />
          </div>

          {/* SVG ROADS & ROUTE */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            {/* Background Highway Lines */}
            <path
              d="M-50,300 C150,280 300,320 600,240 S900,180 1200,160"
              stroke="#1b2820"
              strokeWidth="12"
              fill="none"
              strokeLinecap="round"
            />
            <path
              d="M100,500 C300,420 500,300 700,150"
              stroke="#16221a"
              strokeWidth="8"
              fill="none"
            />

            {/* Active Emergency Transit Route */}
            <path
              d="M240,320 Q480,260 720,160"
              stroke="#2e6d45"
              strokeWidth="5"
              fill="none"
              strokeDasharray="6 6"
              className="animate-pulse"
            />
          </svg>

          {/* WAYPOINT - AMBULANCE POSITION */}
          <div
            className="absolute transition-all duration-1000 -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10"
            style={{
              left: `${ambProgress}%`,
              top: `${52 - (ambProgress - 35) * 0.45}%`,
            }}
          >
            {/* Pulsing ring */}
            <div className="absolute -inset-2 rounded-full bg-[#54c984]/20 animate-ping" />
            <div className="w-10 h-10 rounded-full bg-[#1b4e31] border-2 border-[#54c984] flex items-center justify-center text-lg shadow-[0_0_15px_rgba(84,201,132,0.8)] relative">
              🚑
            </div>
            {/* Floating label */}
            <div className="absolute left-1/2 -translate-x-1/2 top-11 bg-[#090f0c] border border-[#2b4134] px-2.5 py-1 rounded-md text-[10px] font-mono text-[#dbe5df] whitespace-nowrap shadow-md pointer-events-none">
              <span className="font-bold text-[#54c984]">{selectedAmbulance.id}</span> • {selectedAmbulance.speed}
            </div>
          </div>

          {/* WAYPOINT - RECOMMENDED HOSPITAL */}
          <div
            className="absolute -translate-x-1/2 -translate-y-1/2 z-10"
            style={{ left: '72%', top: '35%' }}
          >
            <div className="w-11 h-11 rounded-full bg-[#173b4e] border-2 border-[#4da8da] flex items-center justify-center text-lg shadow-[0_0_20px_rgba(77,168,218,0.7)]">
              🏥
            </div>
            <div className="absolute left-1/2 -translate-x-1/2 top-12 bg-[#090f0c] border border-[#244152] px-3 py-1.5 rounded-lg text-xs font-mono text-[#dbe5df] whitespace-nowrap shadow-lg">
              <div className="font-bold text-[#4da8da]">{recommendedHospital.name}</div>
              <div className="text-[10px] text-[#7896a8]">
                ETA: {recommendedHospital.eta} min • Distance: {recommendedHospital.distance}
              </div>
            </div>
          </div>

          {/* SECONDARY HOSPITAL PIN */}
          <div
            className="absolute -translate-x-1/2 -translate-y-1/2 opacity-75"
            style={{ left: '85%', top: '65%' }}
          >
            <div className="w-8 h-8 rounded-full bg-[#1b2822] border border-[#3b5949] flex items-center justify-center text-xs">
              🏥
            </div>
            <div className="absolute left-1/2 -translate-x-1/2 top-9 bg-[#090f0c] border border-[#213028] px-2 py-0.5 rounded text-[9px] text-[#819289] whitespace-nowrap">
              Metro Medical Center (11 min)
            </div>
          </div>

          {/* MAP HUD OVERLAY - BOTTOM BAR */}
          <div className="absolute bottom-3 left-3 right-3 bg-[#0a100d]/90 backdrop-blur-md border border-[#213127] rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <span className="text-[#72857a]">Assigned Destination:</span>
              <span className="font-bold text-[#e1e9e4]">
                {recommendedHospital.name}
              </span>
            </div>

            <div className="flex items-center gap-4 text-xs font-mono">
              <span className="text-[#83978b]">
                Distance to Trauma Bay: <b className="text-[#54c984]">{recommendedHospital.distance}</b>
              </span>
              <span className="text-[#83978b]">
                ETA: <b className="text-[#54c984]">{recommendedHospital.eta} min</b>
              </span>
              <span className="text-[#83978b]">
                Status: <b className="text-emerald-400">PRIORITY CODE RED TRANSIT</b>
              </span>
            </div>
          </div>
        </div>

        {/* AMBULANCE FLEET SELECTOR STRIP */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 mt-4">
          {ambulances.map((amb) => (
            <div
              key={amb.id}
              onClick={() => setSelectedAmbulance(amb)}
              className={`p-3 rounded-xl border cursor-pointer transition-all ${
                selectedAmbulance.id === amb.id
                  ? 'bg-[#15241c] border-[#397c54] shadow-[0_0_12px_rgba(65,175,108,0.15)]'
                  : 'bg-[#090f0c] border-[#222c25] hover:border-[#304235]'
              }`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="font-mono font-bold text-xs text-[#e1e9e4]">
                  {amb.id}
                </span>
                <span
                  className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                    amb.status === 'EN ROUTE'
                      ? 'bg-[#291818] text-rose-300 border border-[#522929]'
                      : amb.status === 'AVAILABLE'
                      ? 'bg-[#132419] text-[#54c984] border border-[#2a5538]'
                      : 'bg-[#1e2017] text-amber-300 border border-[#4d4826]'
                  }`}
                >
                  {amb.status}
                </span>
              </div>
              <div className="text-[11px] text-[#7e8f85] truncate">
                Paramedic: {amb.paramedic}
              </div>
              <div className="text-[10px] text-[#5b6a61] mt-1 font-mono">
                {amb.location}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
