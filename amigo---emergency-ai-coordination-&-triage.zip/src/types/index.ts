export interface PatientInfo {
  name: string;
  age: number;
  gender: string;
  bloodGroup: string;
  emergencyType: string;
  ambulanceId: string;
}

export interface MedicalVitals {
  bp: number;
  heartRate: number;
  spo2: number;
  temperature: number;
  respRate: number;
  consciousness: string;
  trauma: string;
  painLevel: number;
  glucose: number;
}

export interface ResourceRequirements {
  ICU: boolean;
  Oxygen: boolean;
  Specialist: boolean;
  Trauma: boolean;
  Ventilator: boolean;
  CT: boolean;
  Cardiac: boolean;
  Surgery: boolean;
}

export interface AIAnalysisResult {
  severityScore: number;
  severityTier: 'CRITICAL' | 'URGENT' | 'STABLE';
  clinicalImpression: string;
  criticalRisks: string[];
  requiredResources: ResourceRequirements;
  inTransitDirectives: string[];
  recommendedHospitalRationale: string;
  hospitalHandoverProtocol: string;
  alertLevel: string;
}

export interface Hospital {
  id: string;
  name: string;
  location: string;
  address: string;
  eta: number;
  distance: string;
  icu: boolean;
  oxygen: boolean;
  specialist: boolean;
  trauma: boolean;
  ventilator: boolean;
  ct: boolean;
  cardiac: boolean;
  surgery: boolean;
  capacity: number;
  phone: string;
  icuBedsAvailable: number;
  ventilatorsAvailable: number;
  lat: number;
  lng: number;
}

export interface Ambulance {
  id: string;
  driverName: string;
  paramedic: string;
  status: 'EN ROUTE' | 'AVAILABLE' | 'ON SCENE' | 'AT HOSPITAL';
  patientName: string | null;
  destination: string | null;
  location: string;
  speed: string;
  eta: string | null;
  lat: number;
  lng: number;
}

export interface Reservation {
  id: string;
  caseId?: string;
  hospitalId: string;
  hospitalName: string;
  resourceType: string;
  patientName: string;
  ambulanceId: string;
  status: 'RESERVED' | 'ADMITTED' | 'COMPLETED' | 'CANCELLED';
  createdAt: string;
  eta: string;
  notes?: string;
}

export interface EmergencyCase {
  id: string;
  createdAt: string;
  patient: PatientInfo;
  vitals: MedicalVitals;
  triage: {
    score: number;
    severity: 'CRITICAL' | 'URGENT' | 'STABLE';
    needs: ResourceRequirements;
  };
  aiInsights?: AIAnalysisResult;
  assignedHospitalId: string;
  assignedHospitalName: string;
  backupHospitalId?: string;
  backupHospitalName?: string;
  status: 'EN_ROUTE' | 'ARRIVED' | 'ADMITTED' | 'RESOLVED';
}
