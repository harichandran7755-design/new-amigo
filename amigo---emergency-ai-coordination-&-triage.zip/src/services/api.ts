import {
  AIAnalysisResult,
  Ambulance,
  EmergencyCase,
  Hospital,
  MedicalVitals,
  PatientInfo,
  Reservation,
} from '../types';

export const api = {
  // AI Insights
  async analyzePatient(patient: PatientInfo, vitals: MedicalVitals): Promise<AIAnalysisResult> {
    const res = await fetch('/api/ai/analyze-patient', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ patient, vitals }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to analyze patient with AI');
    }
    return res.json();
  },

  async askCopilot(question: string, patientContext?: any): Promise<string> {
    const res = await fetch('/api/ai/ask-assistant', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, patientContext }),
    });
    if (!res.ok) {
      throw new Error('Failed to ask AI copilot');
    }
    const data = await res.json();
    return data.answer;
  },

  async generateRadioBriefing(payload: {
    patient: PatientInfo;
    vitals: MedicalVitals;
    triage: any;
    hospitalName: string;
  }): Promise<string> {
    const res = await fetch('/api/ai/hospital-briefing', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      throw new Error('Failed to generate radio patch');
    }
    const data = await res.json();
    return data.transcript;
  },

  // Cases (Store and Retrieve)
  async getCases(): Promise<EmergencyCase[]> {
    const res = await fetch('/api/cases');
    if (!res.ok) throw new Error('Failed to fetch emergency cases');
    return res.json();
  },

  async saveCase(caseData: Partial<EmergencyCase>): Promise<EmergencyCase> {
    const res = await fetch('/api/cases', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(caseData),
    });
    if (!res.ok) throw new Error('Failed to save emergency case');
    return res.json();
  },

  async updateCase(id: string, updates: Partial<EmergencyCase>): Promise<EmergencyCase> {
    const res = await fetch(`/api/cases/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update case');
    return res.json();
  },

  // Hospitals
  async getHospitals(): Promise<Hospital[]> {
    const res = await fetch('/api/hospitals');
    if (!res.ok) throw new Error('Failed to fetch hospitals');
    return res.json();
  },

  async updateHospital(id: string, updates: Partial<Hospital>): Promise<Hospital> {
    const res = await fetch(`/api/hospitals/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update hospital');
    return res.json();
  },

  // Ambulances
  async getAmbulances(): Promise<Ambulance[]> {
    const res = await fetch('/api/ambulances');
    if (!res.ok) throw new Error('Failed to fetch ambulances');
    return res.json();
  },

  async updateAmbulance(id: string, updates: Partial<Ambulance>): Promise<Ambulance> {
    const res = await fetch(`/api/ambulances/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update ambulance');
    return res.json();
  },

  // Reservations
  async getReservations(): Promise<Reservation[]> {
    const res = await fetch('/api/reservations');
    if (!res.ok) throw new Error('Failed to fetch reservations');
    return res.json();
  },

  async createReservation(reservation: Partial<Reservation>): Promise<Reservation> {
    const res = await fetch('/api/reservations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(reservation),
    });
    if (!res.ok) throw new Error('Failed to create reservation');
    return res.json();
  },

  async updateReservation(id: string, updates: Partial<Reservation>): Promise<Reservation> {
    const res = await fetch(`/api/reservations/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update reservation');
    return res.json();
  },

  async deleteReservation(id: string): Promise<void> {
    const res = await fetch(`/api/reservations/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to cancel reservation');
  },
};
