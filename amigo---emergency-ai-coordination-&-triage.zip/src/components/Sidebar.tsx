import React from 'react';
import {
  LayoutDashboard,
  Brain,
  MapPin,
  Ambulance,
  Building2,
  Activity,
  Lock,
  History,
  BotMessageSquare,
} from 'lucide-react';

interface SidebarProps {
  activeView: string;
  onSelectView: (view: string) => void;
  online: boolean;
  activeCaseCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onSelectView,
  online,
  activeCaseCount,
}) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'analysis', label: 'Patient Analysis', icon: Brain },
    { id: 'mapView', label: 'Live GPS Map', icon: MapPin },
    { id: 'ambulances', label: 'Ambulances', icon: Ambulance },
    { id: 'hospitals', label: 'Hospital Network', icon: Building2 },
    { id: 'resources', label: 'Resource Status', icon: Activity },
    { id: 'reservations', label: 'Reservations', icon: Lock },
    { id: 'caseHistory', label: 'Saved Cases DB', icon: History, badge: activeCaseCount },
    { id: 'copilot', label: 'Paramedic Copilot', icon: BotMessageSquare },
  ];

  return (
    <aside className="w-64 bg-[#0b100e] border-r border-[#202824] p-5 flex flex-col justify-between fixed top-0 bottom-0 left-0 z-30 transition-all select-none">
      <div>
        {/* AMIGO CATCHY MEDICAL-TECH LOGO */}
        <div
          onClick={() => onSelectView('dashboard')}
          className="flex items-center gap-3 p-2 mb-6 cursor-pointer group"
        >
          <div className="w-11 h-11 rounded-2xl relative flex items-center justify-center bg-gradient-to-br from-[#183f2b] to-[#10261b] border border-[#3c8f61] shadow-[0_0_18px_rgba(53,151,91,0.22)] overflow-hidden shrink-0 group-hover:border-[#54C984] transition-colors">
            <div className="absolute inset-1 rounded-xl border border-[rgba(92,190,128,0.25)] pointer-events-none" />
            <svg viewBox="0 0 64 64" fill="none" className="w-7 h-7 relative z-10">
              {/* Shield */}
              <path
                d="M32 5 L52 13 V29 C52 43 43 53 32 59 C21 53 12 43 12 29 V13 L32 5Z"
                stroke="#54C984"
                strokeWidth="3.5"
                strokeLinejoin="round"
              />
              {/* Medical Cross */}
              <path
                d="M28 18H36V27H45V35H36V44H28V35H19V27H28V18Z"
                fill="#EAF8F0"
              />
              {/* Pulse line */}
              <path
                d="M16 39 H22 L26 34 L30 42 L35 29 L39 39 H48"
                stroke="#54C984"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>

          <div className="flex flex-col justify-center">
            <div className="text-[22px] font-extrabold tracking-[2px] leading-none text-[#f0f6f2] font-mono">
              AM<span className="text-[#49b977]">I</span>GO
            </div>
            <div className="text-[8px] text-[#6f8177] tracking-[1.5px] mt-1.5 uppercase font-medium">
              Emergency Coordination
            </div>
          </div>
        </div>

        {/* NAVIGATION MENU */}
        <nav className="flex flex-col gap-1.5">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectView(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all text-left ${
                  isActive
                    ? 'bg-[#15231c] text-[#7ce0a3] border border-[#274635] shadow-[0_0_12px_rgba(73,185,119,0.12)]'
                    : 'text-[#8a948e] hover:bg-[#151d19] hover:text-[#c9d8cf]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 ${
                      isActive ? 'text-[#54C984]' : 'text-[#707c76]'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#1b3425] text-[#54c984] border border-[#2f5d40] font-mono">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* SYSTEM STATUS */}
      <div className="bg-[#111714] border border-[#252e29] rounded-xl p-3.5 mt-4">
        <div className="text-[10px] text-[#707b75] font-semibold tracking-wider uppercase mb-1.5">
          System Telemetry
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#65c98b]">
            <span
              className={`w-2 h-2 rounded-full ${
                online
                  ? 'bg-[#35c875] shadow-[0_0_8px_rgba(53,200,117,0.8)] animate-pulse'
                  : 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]'
              }`}
            />
            {online ? 'AMIGO ONLINE' : 'OFFLINE'}
          </div>
          <span className="text-[9px] text-[#5a6860] font-mono">v2.5 AI-CORE</span>
        </div>
        <div className="text-[10px] text-[#606d66] mt-2 border-t border-[#1a231e] pt-1.5 flex items-center justify-between">
          <span>Gemini 3.8 Flash</span>
          <span className="text-[#49b977]">Active</span>
        </div>
      </div>
    </aside>
  );
};
