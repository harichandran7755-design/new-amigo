import React, { useState } from 'react';
import { Bot, Send, Sparkles, X, Loader2 } from 'lucide-react';
import { api } from '../services/api';
import { PatientInfo, MedicalVitals, AIAnalysisResult } from '../types';

interface CopilotModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: PatientInfo;
  vitals: MedicalVitals;
  aiResult: AIAnalysisResult | null;
}

export const CopilotModal: React.FC<CopilotModalProps> = ({
  isOpen,
  onClose,
  patient,
  vitals,
  aiResult,
}) => {
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string; time: string }>>([
    {
      sender: 'ai',
      text: `AMIGO In-Transit Medical Copilot active. Monitoring ${patient.name || 'Emergency Patient'} (${patient.emergencyType}). Ask any in-transit stabilization directive or medication dosage query.`,
      time: 'Just now',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const quickPrompts = [
    'Patient BP dropping below 80, what vasopressor protocol?',
    'Patient begins active tonic-clonic seizure en route',
    'SpO2 remains 88% on high-flow mask, next airway step?',
    'Check contraindications for sublingual nitroglycerin',
  ];

  const handleSend = async (questionText?: string) => {
    const textToSend = questionText || input;
    if (!textToSend.trim() || loading) return;

    const userMsg = {
      sender: 'user' as const,
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!questionText) setInput('');
    setLoading(true);

    try {
      const answer = await api.askCopilot(textToSend, {
        patient,
        vitals,
        triageSummary: aiResult?.clinicalImpression,
      });

      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: answer,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: 'Error contacting AI Copilot. Fallback directive: Maintain ABCs, administer high-flow oxygen, maintain IV access, notify receiving trauma center.',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-[#0d1310] border border-[#2b4134] rounded-2xl flex flex-col h-[600px] shadow-[0_20px_70px_rgba(0,0,0,0.85)] relative overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-[#09100c] border-b border-[#202c24] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#14281c] border border-[#3b875d] flex items-center justify-center text-[#54c984]">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-[#e1e9e4]">AMIGO Emergency Paramedic Copilot</h3>
                <span className="text-[10px] bg-[#16271e] text-[#54c984] border border-[#2e533d] px-2 py-0.5 rounded-full font-mono">
                  Gemini 3.8 Flash
                </span>
              </div>
              <p className="text-xs text-[#718078]">
                Real-time clinical protocols & in-transit emergency decision support
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#75847b] hover:text-[#d3ded8] p-1.5 rounded-lg hover:bg-[#151f19]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Patient Vitals Strip */}
        <div className="bg-[#0b1410] border-b border-[#1b261f] px-4 py-2 flex items-center justify-between text-xs font-mono text-[#8a9b91]">
          <span>
            Patient: <b className="text-[#d8e2dc]">{patient.name || 'Emergency Patient'}</b>
          </span>
          <span className="flex items-center gap-3">
            <span>BP: <b className="text-[#e2aba8]">{vitals.bp}</b></span>
            <span>HR: <b className="text-[#a8e2b8]">{vitals.heartRate}</b></span>
            <span>SpO2: <b className="text-[#54c984]">{vitals.spo2}%</b></span>
            <span>Temp: <b className="text-[#e2d8a8]">{vitals.temperature}°C</b></span>
          </span>
        </div>

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-xl p-3.5 text-xs leading-relaxed whitespace-pre-wrap ${
                  m.sender === 'user'
                    ? 'bg-[#1b442d] text-[#e7f7ed] border border-[#2f754e]'
                    : 'bg-[#101713] text-[#d0ded5] border border-[#243329]'
                }`}
              >
                {m.sender === 'ai' && (
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-[#54c984] mb-1.5 uppercase tracking-wider">
                    <Sparkles className="w-3 h-3" />
                    EMS Protocol Directive
                  </div>
                )}
                {m.text}
              </div>
              <span className="text-[10px] text-[#55635b] mt-1 px-1 font-mono">{m.time}</span>
            </div>
          ))}
          {loading && (
            <div className="flex items-center gap-2 text-xs text-[#54c984] bg-[#0c1611] p-3 rounded-xl border border-[#1e3426] w-fit">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>AMIGO AI analyzing clinical protocols...</span>
            </div>
          )}
        </div>

        {/* Quick Prompts */}
        <div className="px-4 py-2 bg-[#09100c] border-t border-[#1d2720] flex gap-2 overflow-x-auto text-[11px]">
          {quickPrompts.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="whitespace-nowrap px-2.5 py-1 bg-[#121c17] hover:bg-[#18261f] border border-[#26372c] text-[#86a192] rounded-lg transition-colors"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input bar */}
        <div className="p-3 bg-[#0a0f0d] border-t border-[#1f2923] flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type clinical query (e.g. drug dosing, resuscitation steps)..."
            className="flex-1 bg-[#070b09] border border-[#26352b] rounded-xl px-3.5 py-2.5 text-xs text-[#dfe6e2] focus:outline-none focus:border-[#4b8d65]"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading || !input.trim()}
            className="p-2.5 rounded-xl bg-[#237344] hover:bg-[#2b8250] text-[#f1fff6] disabled:opacity-50 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
