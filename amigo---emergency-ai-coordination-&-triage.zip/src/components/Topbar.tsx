import React, { useEffect, useState } from 'react';
import { Bot, Radio, RefreshCw } from 'lucide-react';

interface TopbarProps {
  title: string;
  subtitle: string;
  activeAmbulanceUnit?: string;
  assignedHospital?: string;
  onOpenCopilot: () => void;
  onRefreshData: () => void;
  isRefreshing?: boolean;
}

export const Topbar: React.FC<TopbarProps> = ({
  title,
  subtitle,
  activeAmbulanceUnit = 'AMB-204',
  assignedHospital = 'CityCare Emergency Hospital',
  onOpenCopilot,
  onRefreshData,
  isRefreshing = false,
}) => {
  const [clock, setClock] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setClock(
        now.toLocaleString('en-IN', {
          dateStyle: 'medium',
          timeStyle: 'medium',
        })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="h-[72px] bg-[#0a0f0d] border-b border-[#202823] flex items-center justify-between px-7 sticky top-0 z-20">
      <div>
        <h1 className="text-xl font-bold text-[#e7ece9] tracking-tight">{title}</h1>
        <p className="text-xs text-[#727d77] mt-0.5">{subtitle}</p>
      </div>

      <div className="flex items-center gap-4">
        {/* Active Dispatch Live Pill */}
        <div className="hidden lg:flex items-center gap-2 bg-[#101914] border border-[#273d2f] px-3 py-1.5 rounded-lg text-xs">
          <Radio className="w-3.5 h-3.5 text-[#54c984] animate-pulse" />
          <span className="text-[#84948a]">Active Link:</span>
          <span className="font-mono font-bold text-[#54c984]">{activeAmbulanceUnit}</span>
          <span className="text-[#435248]">→</span>
          <span className="text-[#b5c7bd] truncate max-w-[170px] font-medium">
            {assignedHospital}
          </span>
        </div>

        {/* Sync Data Button */}
        <button
          onClick={onRefreshData}
          title="Refresh backend data"
          className="p-2 rounded-lg bg-[#111714] border border-[#242d28] text-[#86958d] hover:text-[#d3ded8] hover:border-[#38493f] transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-[#54c984]' : ''}`} />
        </button>

        {/* Paramedic Copilot Launch Button */}
        <button
          onClick={onOpenCopilot}
          className="flex items-center gap-2 bg-[#16271e] hover:bg-[#1d3528] border border-[#30523e] text-[#69d997] px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-[0_0_10px_rgba(84,201,132,0.15)] transition-all"
        >
          <Bot className="w-4 h-4 text-[#54c984]" />
          <span>Paramedic Copilot</span>
        </button>

        {/* Clock */}
        <div className="font-mono text-xs text-[#76b58f] bg-[#0c1410] border border-[#202d25] px-3 py-1.5 rounded-lg">
          {clock || 'Syncing clock...'}
        </div>
      </div>
    </header>
  );
};
