import React, { useState, useEffect } from 'react';
import { Phone, PhoneCall, Volume2, CheckCircle2, X, Radio } from 'lucide-react';
import { Hospital, PatientInfo, MedicalVitals, AIAnalysisResult } from '../types';
import { api } from '../services/api';

interface CallModalProps {
  isOpen: boolean;
  onClose: () => void;
  hospital: Hospital;
  patient: PatientInfo;
  vitals: MedicalVitals;
  aiResult: AIAnalysisResult | null;
  onReservationCreated?: () => void;
}

export const CallModal: React.FC<CallModalProps> = ({
  isOpen,
  onClose,
  hospital,
  patient,
  vitals,
  aiResult,
  onReservationCreated,
}) => {
  const [callPhase, setCallPhase] = useState<'connecting' | 'connected' | 'transmitting'>('connecting');
  const [radioPatch, setRadioPatch] = useState<string>('');
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [reserved, setReserved] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setCallPhase('connecting');
      setReserved(false);
      const timer = setTimeout(() => {
        setCallPhase('connected');
      }, 1400);

      // Request Gemini radio patch brief
      api
        .generateRadioBriefing({
          patient,
          vitals,
          triage: aiResult,
          hospitalName: hospital.name,
        })
        .then((script) => {
          setRadioPatch(script);
        })
        .catch(() => {
          setRadioPatch(
            `Ambulance ${patient.ambulanceId} to ${hospital.name} Emergency. Priority incoming traffic. Patient ${patient.name || 'Unknown'}, ${patient.age}y ${patient.gender}. Presenting with ${patient.emergencyType}. Vitals: BP ${vitals.bp}, HR ${vitals.heartRate}, SpO2 ${vitals.spo2}%. Paramedics on scene. ETA is ${hospital.eta} minutes. Over.`
          );
        });

      return () => {
        clearTimeout(timer);
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
      };
    }
  }, [isOpen, hospital.name, patient, vitals, aiResult]);

  const handleSpeakRadioPatch = () => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToSpeak = radioPatch || `${patient.ambulanceId} calling ${hospital.name}`;
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.rate = 1.05;
    utterance.pitch = 0.95;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const handleReserveResources = async () => {
    try {
      const resourceType = aiResult?.requiredResources.ICU
        ? 'ICU Bed & Trauma Resuscitation Bay'
        : aiResult?.requiredResources.Cardiac
        ? 'Cardiac Cath Lab & Monitoring Bay'
        : 'Emergency Resuscitation Bay';

      await api.createReservation({
        hospitalId: hospital.id,
        hospitalName: hospital.name,
        resourceType,
        patientName: patient.name || 'Emergency Patient',
        ambulanceId: patient.ambulanceId || 'AMB-204',
        eta: `${hospital.eta} min`,
        notes: `Triage: ${aiResult?.severityTier || 'URGENT'} - Alert: ${aiResult?.alertLevel || 'Pre-alert'}`,
      });
      setReserved(true);
      if (onReservationCreated) onReservationCreated();
    } catch (err) {
      console.error('Reservation failed:', err);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-[#0d1310] border border-[#35463c] rounded-2xl p-6 shadow-[0_20px_70px_rgba(0,0,0,0.85)] relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#75847b] hover:text-[#d3ded8] p-1.5 rounded-lg hover:bg-[#151f19]"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-[#172d21] border border-[#3b875d] flex items-center justify-center text-[#54c984]">
            {callPhase === 'connecting' ? (
              <PhoneCall className="w-5 h-5 animate-bounce" />
            ) : (
              <Phone className="w-5 h-5" />
            )}
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#e1e9e4]">
              Emergency Telemetry Channel
            </h3>
            <p className="text-xs text-[#728078]">
              Direct radio & telemetry link: {patient.ambulanceId} ↔ {hospital.name}
            </p>
          </div>
        </div>

        {/* Connection status pill */}
        <div className="flex items-center justify-between bg-[#0a0f0d] border border-[#212b25] px-3.5 py-2 rounded-xl mb-4 text-xs">
          <div className="flex items-center gap-2">
            <Radio className="w-3.5 h-3.5 text-[#54c984] animate-pulse" />
            <span className="text-[#7c8b82]">Channel Status:</span>
            <span
              className={`font-semibold font-mono ${
                callPhase === 'connecting' ? 'text-amber-400' : 'text-[#54c984]'
              }`}
            >
              {callPhase === 'connecting' ? 'CONNECTING VIA ENCRYPTED EMS LINK...' : 'CONNECTED (SIGNAL: 98%)'}
            </span>
          </div>
          <span className="text-[#65766d] font-mono">{hospital.phone}</span>
        </div>

        {/* Transmission & Hospital Data */}
        <div className="space-y-3 mb-5">
          <div className="bg-[#090f0c] border border-[#222c26] rounded-xl p-3.5 text-xs space-y-2">
            <div className="flex justify-between text-[#818f86]">
              <span>Patient:</span>
              <span className="font-semibold text-[#dfe6e2]">
                {patient.name || 'Unknown Patient'} ({patient.age || '--'}y, {patient.gender})
              </span>
            </div>
            <div className="flex justify-between text-[#818f86]">
              <span>Emergency Type:</span>
              <span className="font-semibold text-[#e59b58]">{patient.emergencyType}</span>
            </div>
            <div className="flex justify-between text-[#818f86]">
              <span>ETA & Distance:</span>
              <span className="font-semibold text-[#54c984]">
                {hospital.eta} min ({hospital.distance})
              </span>
            </div>
            <div className="flex justify-between text-[#818f86]">
              <span>Emergency Alert Tier:</span>
              <span className="font-semibold text-rose-400">
                {aiResult?.alertLevel || 'Pre-alerting ED Team'}
              </span>
            </div>
          </div>

          {/* Radio Patch Script */}
          <div className="bg-[#070b09] border border-[#1e2a22] rounded-xl p-3.5">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#6b7b72] flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#54c984]" />
                EMS Radio Patch Transcript
              </span>
              <button
                onClick={handleSpeakRadioPatch}
                className={`flex items-center gap-1.5 text-[11px] px-2.5 py-1 rounded-md border transition-all ${
                  isSpeaking
                    ? 'bg-rose-900/40 border-rose-600 text-rose-300 animate-pulse'
                    : 'bg-[#15231c] border-[#294634] text-[#63d391] hover:bg-[#1a3025]'
                }`}
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>{isSpeaking ? 'Stop Radio Audio' : 'Transmit Audio Voice'}</span>
              </button>
            </div>
            <p className="text-xs text-[#a3b3aa] leading-relaxed font-mono bg-[#050806] p-2.5 rounded-lg border border-[#17221b] max-h-36 overflow-y-auto">
              {radioPatch || 'Generating standardized EMS radio patch transmission with Gemini AI...'}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2.5">
          <button
            onClick={handleReserveResources}
            disabled={reserved}
            className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${
              reserved
                ? 'bg-[#12281b] border border-[#2a6840] text-[#54c984]'
                : 'bg-[#237344] hover:bg-[#2b8250] text-[#f1fff6] border border-[#3f9a63] shadow-[0_0_14px_rgba(50,145,87,0.2)]'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{reserved ? 'RESOURCES LOCKED & RESERVED' : 'LOCK & RESERVE ICU / BAY'}</span>
          </button>

          <button
            onClick={onClose}
            className="py-3 px-5 rounded-xl font-bold text-xs bg-[#151d19] border border-[#334139] text-[#b7c5bd] hover:bg-[#1c2721] transition-colors"
          >
            END CALL
          </button>
        </div>
      </div>
    </div>
  );
};
